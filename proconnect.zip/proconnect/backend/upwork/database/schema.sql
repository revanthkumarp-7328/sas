-- Service Marketplace Database Schema
-- Created: April 8, 2026
-- This script creates all tables needed for the application

-- Drop existing database (if running fresh) - CAUTION: This deletes all data
-- DROP DATABASE IF EXISTS service_marketplace;

-- Create database
CREATE DATABASE IF NOT EXISTS service_marketplace;
USE service_marketplace;

-- ============================================
-- TABLE 1: USERS
-- Base table for all users (customers, professionals, admins, support)
-- ============================================
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL COMMENT 'Login email must be unique',
    password VARCHAR(255) NOT NULL COMMENT 'BCrypt hashed password',
    name VARCHAR(255) NOT NULL COMMENT 'Full name of user',
    phone VARCHAR(20) COMMENT 'Contact phone number',
    role ENUM('USER', 'PROFESSIONAL', 'ADMIN', 'SUPPORT') NOT NULL DEFAULT 'USER' COMMENT 'User role determines permissions',
    profile_picture_url VARCHAR(500) COMMENT 'URL to profile picture',
    is_active BOOLEAN DEFAULT TRUE COMMENT 'Soft delete flag',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'Account creation time',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Last update time',
    
    INDEX idx_email (email) COMMENT 'Fast email lookups for login',
    INDEX idx_role (role) COMMENT 'Fast role filtering',
    INDEX idx_created_at (created_at) COMMENT 'Sort by creation date'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
COMMENT='Core user table - every person in the system';

-- ============================================
-- TABLE 2: PROFESSIONALS
-- Extends USERS table for professional-specific data
-- ============================================
CREATE TABLE IF NOT EXISTS professionals (
    id INT PRIMARY KEY COMMENT 'Foreign key to users.id',
    bio TEXT COMMENT 'Professional bio/qualifications',
    hourly_rate DECIMAL(10, 2) COMMENT 'Base hourly rate',
    location VARCHAR(255) COMMENT 'Service location/city',
    total_rating DECIMAL(3, 2) DEFAULT 0 COMMENT 'Average rating (0-5)',
    rating_count INT DEFAULT 0 COMMENT 'Number of reviews',
    verification_status ENUM('PENDING', 'VERIFIED', 'REJECTED') DEFAULT 'PENDING' COMMENT 'Admin verification status',
    years_of_experience INT COMMENT 'Years of experience in field',
    bank_account VARCHAR(255) COMMENT 'Bank account for payments',
    total_earnings DECIMAL(15, 2) DEFAULT 0 COMMENT 'Total lifetime earnings',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'When profile was created',
    
    FOREIGN KEY (id) REFERENCES users(id) ON DELETE CASCADE COMMENT 'Links to parent user',
    INDEX idx_location (location) COMMENT 'Search by location',
    INDEX idx_verification_status (verification_status) COMMENT 'Filter verified professionals',
    INDEX idx_rating (total_rating) COMMENT 'Sort by rating'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
COMMENT='Professional-specific data - extends users table';

-- ============================================
-- TABLE 3: JOBS
-- Jobs posted by users seeking professionals
-- ============================================
CREATE TABLE IF NOT EXISTS jobs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL COMMENT 'User who posted the job',
    title VARCHAR(255) NOT NULL COMMENT 'Job title',
    description TEXT NOT NULL COMMENT 'Detailed job description',
    category VARCHAR(100) NOT NULL COMMENT 'Job category (e.g., Home Services, Business)',
    subcategory VARCHAR(100) COMMENT 'Job subcategory (e.g., Cleaning, Plumbing)',
    location VARCHAR(255) COMMENT 'Job location',
    budget_min DECIMAL(10, 2) COMMENT 'Minimum budget',
    budget_max DECIMAL(10, 2) COMMENT 'Maximum budget',
    job_type ENUM('FIXED', 'HOURLY') DEFAULT 'HOURLY' COMMENT 'Fixed price or hourly rate',
    duration_hours INT COMMENT 'Estimated duration in hours',
    urgency ENUM('LOW', 'MEDIUM', 'HIGH') DEFAULT 'MEDIUM' COMMENT 'Job urgency',
    status ENUM('OPEN', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED') DEFAULT 'OPEN' COMMENT 'Job status',
    required_skills TEXT COMMENT 'Skills required for the job',
    preferred_experience VARCHAR(100) COMMENT 'Preferred experience level',
    attachments TEXT COMMENT 'File attachments (JSON array of file URLs)',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'Job posting date',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Last update date',

    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE COMMENT 'Cascade delete when user is removed',
    INDEX idx_user_id (user_id) COMMENT 'Find jobs by user',
    INDEX idx_category (category) COMMENT 'Filter by category',
    INDEX idx_location (location) COMMENT 'Filter by location',
    INDEX idx_status (status) COMMENT 'Find open jobs',
    INDEX idx_created_at (created_at) COMMENT 'Sort by date',
    INDEX idx_budget_max (budget_max) COMMENT 'Filter by budget range'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
COMMENT='Jobs posted by users looking to hire professionals';

-- ============================================
-- TABLE 4: APPLICATIONS
-- Professional applications for jobs
-- ============================================
CREATE TABLE IF NOT EXISTS applications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    job_id INT NOT NULL COMMENT 'Job being applied for',
    professional_id INT NOT NULL COMMENT 'Professional applying',
    proposed_price DECIMAL(10, 2) COMMENT 'Professional proposed price',
    proposed_duration INT COMMENT 'Proposed duration in hours',
    cover_letter TEXT COMMENT 'Professional cover letter/explanation',
    status ENUM('PENDING', 'ACCEPTED', 'REJECTED', 'WITHDRAWN') DEFAULT 'PENDING' COMMENT 'Application status',
    applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'Application date',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Last update date',

    FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE COMMENT 'Cascade delete when job is removed',
    FOREIGN KEY (professional_id) REFERENCES professionals(id) ON DELETE CASCADE COMMENT 'Cascade delete when professional is removed',
    INDEX idx_job_id (job_id) COMMENT 'Find applications for a job',
    INDEX idx_professional_id (professional_id) COMMENT 'Find applications by professional',
    INDEX idx_status (status) COMMENT 'Filter by status',
    UNIQUE KEY unique_job_professional (job_id, professional_id) COMMENT 'One application per job per professional'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
COMMENT='Professional applications for jobs';

-- ============================================
-- TABLE 5: REVIEWS
-- Ratings and feedback from users about professionals
-- ============================================
CREATE TABLE IF NOT EXISTS reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    application_id INT UNIQUE NOT NULL COMMENT 'Link to completed application (unique - one review per application)',
    user_id INT NOT NULL COMMENT 'User who gave the review',
    professional_id INT NOT NULL COMMENT 'Professional being reviewed',
    rating INT NOT NULL COMMENT 'Rating from 1 to 5' CHECK (rating >= 1 AND rating <= 5),
    comment TEXT COMMENT 'Optional written feedback',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'Review creation date',
    
    FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE COMMENT 'Links to application',
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE COMMENT 'Reviewer',
    FOREIGN KEY (professional_id) REFERENCES professionals(id) ON DELETE CASCADE COMMENT 'Professional being reviewed',
    
    INDEX idx_professional_id (professional_id) COMMENT 'Find all reviews for a professional',
    INDEX idx_created_at (created_at) COMMENT 'Sort by date'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
COMMENT='Reviews/ratings given by users to professionals after job completion';

-- ============================================
-- TABLE 6: SUPPORT_TICKETS
-- Customer support ticket system
-- ============================================
CREATE TABLE IF NOT EXISTS support_tickets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL COMMENT 'User who created the ticket',
    assigned_to INT COMMENT 'Support agent assigned to this ticket',
    title VARCHAR(255) NOT NULL COMMENT 'Ticket title',
    description TEXT NOT NULL COMMENT 'Detailed description of issue',
    status ENUM('OPEN', 'IN_PROGRESS', 'RESOLVED', 'CLOSED') DEFAULT 'OPEN' COMMENT 'Current status',
    category VARCHAR(100) COMMENT 'Issue category (e.g., Payment, Booking)',
    priority INT DEFAULT 2 COMMENT '1=HIGH, 2=MEDIUM, 3=LOW' CHECK (priority IN (1, 2, 3)),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'When ticket was created',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Last update',
    resolved_at TIMESTAMP NULL COMMENT 'When issue was resolved',
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE COMMENT 'Ticket creator',
    FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL COMMENT 'Support agent (NULL if unassigned)',
    
    INDEX idx_user_id (user_id) COMMENT 'Find tickets by user',
    INDEX idx_assigned_to (assigned_to) COMMENT 'Find tickets assigned to agent',
    INDEX idx_status (status) COMMENT 'Filter by status',
    INDEX idx_priority (priority) COMMENT 'Sort by priority',
    INDEX idx_created_at (created_at) COMMENT 'Sort by date'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
COMMENT='Support tickets for customer service';

-- ============================================
-- SAMPLE DATA (Optional - for testing)
-- ============================================
-- Uncomment to insert test data

/*
-- Insert test users
INSERT INTO users (email, password, name, phone, role, is_active) VALUES
('user1@example.com', '$2a$10$dXJ3SW6G7P50eS3BQzV98.uu8M.8aO/Qjqr0EkYT9nz9L9Kz8Cq3W', 'John Customer', '9876543210', 'USER', TRUE),
('professional1@example.com', '$2a$10$dXJ3SW6G7P50eS3BQzV98.uu8M.8aO/Qjqr0EkYT9nz9L9Kz8Cq3W', 'Jane Developer', '9876543211', 'PROFESSIONAL', TRUE),
('admin@example.com', '$2a$10$dXJ3SW6G7P50eS3BQzV98.uu8M.8aO/Qjqr0EkYT9nz9L9Kz8Cq3W', 'Admin User', '9876543212', 'ADMIN', TRUE);

-- Insert professional profile
INSERT INTO professionals (id, bio, hourly_rate, location, years_of_experience, verification_status) VALUES
(2, 'Expert web developer with 5 years experience', 50.00, 'New York', 5, 'VERIFIED');

-- Insert jobs
INSERT INTO jobs (user_id, title, description, category, location, budget_min, budget_max, job_type, duration_hours, urgency, status, required_skills) VALUES
(1, 'Website Development', 'Need a full-stack web developer for e-commerce site', 'Tech Services', 'New York', 2000.00, 5000.00, 'FIXED', 40, 'HIGH', 'OPEN', 'JavaScript, React, Node.js, MongoDB'),
(1, 'Mobile App Development', 'iOS and Android app for fitness tracking', 'Tech Services', 'Remote', 3000.00, 8000.00, 'FIXED', 60, 'MEDIUM', 'OPEN', 'React Native, Firebase, iOS, Android');
*/

-- ============================================
-- CREATE INDEXES FOR PERFORMANCE
-- ============================================
CREATE INDEX idx_users_email_role ON users(email, role);
CREATE INDEX idx_professionals_rating_location ON professionals(total_rating, location);
CREATE INDEX idx_jobs_user_status ON jobs(user_id, status);
CREATE INDEX idx_applications_status_date ON applications(status, applied_at);
CREATE INDEX idx_support_tickets_status_priority ON support_tickets(status, priority);

-- ============================================
-- SCHEMA CREATION COMPLETE
-- ============================================
-- The database is now ready to use!
-- You can comment/uncomment the SAMPLE DATA section to insert test records
