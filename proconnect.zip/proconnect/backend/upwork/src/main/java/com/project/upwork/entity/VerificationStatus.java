package com.project.upwork.entity;

/**
 * Verification Status for Professionals
 */
public enum VerificationStatus {
    PENDING,   // Awaiting admin review
    VERIFIED,  // Approved by admin
    REJECTED   // Rejected by admin
}
