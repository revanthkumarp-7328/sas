package com.project.upwork.service;

import com.project.upwork.dto.CreateProfessionalRequestDTO;
import com.project.upwork.dto.ProfessionalDTO;
import com.project.upwork.entity.Professional;
import com.project.upwork.entity.VerificationStatus;
import com.project.upwork.exception.ResourceNotFoundException;
import com.project.upwork.repository.ProfessionalRepository;
import com.project.upwork.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

/**
 * Professional Service
 * Handles professional profile management and search
 */
@Service
@Transactional
public class ProfessionalService {
    
    @Autowired
    private ProfessionalRepository professionalRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    /**
     * Get professional by ID
     */
    public ProfessionalDTO getProfessionalById(Long professionalId) {
        Professional professional = professionalRepository.findById(professionalId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Professional", "id", professionalId)
                );
        
        return convertProfessionalToDTO(professional);
    }
    
    /**
     * Update professional profile
     */
    public ProfessionalDTO updateProfessional(Long professionalId, CreateProfessionalRequestDTO updateRequest) {
        Professional professional = professionalRepository.findById(professionalId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Professional", "id", professionalId)
                );
        
        // Update fields
        if (updateRequest.getBio() != null && !updateRequest.getBio().isEmpty()) {
            professional.setBio(updateRequest.getBio());
        }
        
        if (updateRequest.getHourlyRate() != null) {
            professional.setHourlyRate(updateRequest.getHourlyRate());
        }
        
        if (updateRequest.getLocation() != null && !updateRequest.getLocation().isEmpty()) {
            professional.setLocation(updateRequest.getLocation());
        }
        
        if (updateRequest.getYearsOfExperience() != null) {
            professional.setYearsOfExperience(updateRequest.getYearsOfExperience());
        }
        
        if (updateRequest.getBankAccount() != null && !updateRequest.getBankAccount().isEmpty()) {
            professional.setBankAccount(updateRequest.getBankAccount());
        }
        
        professional = professionalRepository.save(professional);
        
        return convertProfessionalToDTO(professional);
    }
    
    /**
     * Get all verified professionals with pagination
     */
    public Page<ProfessionalDTO> getAllVerifiedProfessionals(Pageable pageable) {
        return professionalRepository.findByVerificationStatus(VerificationStatus.VERIFIED, pageable)
                .map(this::convertProfessionalToDTO);
    }
    
    /**
     * Search professionals by location
     */
    public Page<ProfessionalDTO> searchByLocation(String location, Pageable pageable) {
        return professionalRepository.findByLocationAndVerificationStatus(
                location, VerificationStatus.VERIFIED, pageable)
                .map(this::convertProfessionalToDTO);
    }
    
    /**
     * Search professionals by name
     */
    public Page<ProfessionalDTO> searchByName(String name, Pageable pageable) {
        return professionalRepository.searchByName(name, pageable)
                .map(this::convertProfessionalToDTO);
    }
    
    /**
     * Search professionals by location and minimum rating
     */
    public Page<ProfessionalDTO> searchByLocationAndRating(String location, BigDecimal minRating, Pageable pageable) {
        return professionalRepository.findByLocationAndMinRating(location, minRating, pageable)
                .map(this::convertProfessionalToDTO);
    }
    
    /**
     * Get top-rated professionals
     */
    public java.util.List<ProfessionalDTO> getTopRatedProfessionals(int limit) {
        return professionalRepository.findTopRatedProfessionals(limit).stream()
                .map(this::convertProfessionalToDTO)
                .toList();
    }
    
    /**
     * Get current authenticated professional
     */
    public ProfessionalDTO getCurrentProfessional() {
        String email = SecurityContextHolder.getContext()
                .getAuthentication().getName();
        
        Long userId = userRepository.findByEmail(email)
                .orElseThrow(() ->
                        new ResourceNotFoundException("User", "email", email)
                )
                .getId();
        
        return getProfessionalById(userId);
    }
    
    /**
     * Helper method to convert Professional to ProfessionalDTO
     */
    private ProfessionalDTO convertProfessionalToDTO(Professional professional) {
        return ProfessionalDTO.builder()
                .id(professional.getId())
                .name(professional.getUser().getName())
                .email(professional.getUser().getEmail())
                .bio(professional.getBio())
                .hourlyRate(professional.getHourlyRate())
                .location(professional.getLocation())
                .totalRating(professional.getTotalRating())
                .ratingCount(professional.getRatingCount())
                .verificationStatus(professional.getVerificationStatus().toString())
                .yearsOfExperience(professional.getYearsOfExperience())
                .totalEarnings(professional.getTotalEarnings())
                .profilePictureUrl(professional.getUser().getProfilePictureUrl())
                .createdAt(professional.getCreatedAt())
                .build();
    }
}
