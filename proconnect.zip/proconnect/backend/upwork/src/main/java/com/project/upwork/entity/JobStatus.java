package com.project.upwork.entity;

/**
 * Job Status Enumeration
 * Represents the lifecycle of a job posting
 */
public enum JobStatus {
    OPEN,         // Job is open for applications
    IN_PROGRESS,  // Job is assigned and work is in progress
    COMPLETED,    // Job has been completed
    CANCELLED     // Job has been cancelled
}