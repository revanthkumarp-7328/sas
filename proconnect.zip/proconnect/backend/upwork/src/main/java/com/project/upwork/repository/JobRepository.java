package com.project.upwork.repository;

import com.project.upwork.entity.Job;
import com.project.upwork.entity.JobStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

/**
 * Job Repository - Data access layer for Job entities
 */
@Repository
public interface JobRepository extends JpaRepository<Job, Long> {

    // Find jobs by user
    Page<Job> findByUserId(Long userId, Pageable pageable);

    // Find jobs by status
    Page<Job> findByStatus(JobStatus status, Pageable pageable);

    // Find jobs by category
    Page<Job> findByCategory(String category, Pageable pageable);

    // Find jobs by location
    Page<Job> findByLocation(String location, Pageable pageable);

    // Search jobs by title or description
    @Query("SELECT j FROM Job j WHERE " +
           "(LOWER(j.title) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(j.description) LIKE LOWER(CONCAT('%', :keyword, '%'))) AND " +
           "j.status = :status")
    Page<Job> searchJobs(@Param("keyword") String keyword,
                        @Param("status") JobStatus status,
                        Pageable pageable);

    // Find jobs by budget range
    @Query("SELECT j FROM Job j WHERE j.budgetMax >= :minBudget AND j.budgetMin <= :maxBudget AND j.status = :status")
    Page<Job> findByBudgetRange(@Param("minBudget") BigDecimal minBudget,
                               @Param("maxBudget") BigDecimal maxBudget,
                               @Param("status") JobStatus status,
                               Pageable pageable);

    // Find jobs by category and location
    Page<Job> findByCategoryAndLocation(String category, String location, Pageable pageable);

    // Count jobs by status
    long countByStatus(JobStatus status);

    // Count jobs by user
    long countByUserId(Long userId);

    // Find recent jobs
    @Query("SELECT j FROM Job j WHERE j.status = :status ORDER BY j.createdAt DESC")
    List<Job> findRecentJobs(@Param("status") JobStatus status, Pageable pageable);
}