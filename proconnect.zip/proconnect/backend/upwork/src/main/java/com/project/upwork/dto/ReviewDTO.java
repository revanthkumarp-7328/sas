package com.project.upwork.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Review DTO - Response DTO for review
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReviewDTO {
    private Long id;
    private Long applicationId;
    private Long userId;
    private String userName;
    private Long professionalId;
    private String professionalName;
    private Integer rating;
    private String comment;
    private LocalDateTime createdAt;
}
