package com.project.upwork.dto;

import com.project.upwork.entity.JobType;
import com.project.upwork.entity.Urgency;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * Create Job Request DTO - For creating new job postings
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CreateJobRequestDTO {

    @NotBlank(message = "Job title is required")
    private String title;

    @NotBlank(message = "Job description is required")
    private String description;

    @NotBlank(message = "Category is required")
    private String category;

    private String location;

    private BigDecimal budgetMin;

    private BigDecimal budgetMax;

    @NotNull(message = "Job type is required")
    private JobType jobType;

    private Integer durationHours;

    @NotNull(message = "Urgency is required")
    private Urgency urgency;

    private String requiredSkills;

    private String preferredExperience;

    private String attachments;
}