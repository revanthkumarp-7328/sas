package com.project.upwork.service;

import com.project.upwork.dto.SupportTicketDTO;
import com.project.upwork.entity.*;
import com.project.upwork.exception.ResourceNotFoundException;
import com.project.upwork.repository.SupportTicketRepository;
import com.project.upwork.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

/**
 * Support Service
 * Handles support ticket management
 */
@Service
@Transactional
public class SupportService {
    
    @Autowired
    private SupportTicketRepository supportTicketRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    /**
     * Get ticket by ID
     */
    public SupportTicketDTO getTicketById(Long ticketId) {
        SupportTicket ticket = supportTicketRepository.findById(ticketId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Support Ticket", "id", ticketId)
                );
        
        return convertTicketToDTO(ticket);
    }
    
    /**
     * Create support ticket
     */
    public SupportTicketDTO createTicket(Long userId, String title, String description, String category, Integer priority) {
        User user = userRepository.findById(userId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("User", "id", userId)
                );
        
        SupportTicket ticket = SupportTicket.builder()
                .user(user)
                .title(title)
                .description(description)
                .category(category != null ? category : "General")
                .priority(priority != null ? priority : 2)
                .status(SupportTicketStatus.OPEN)
                .build();
        
        ticket = supportTicketRepository.save(ticket);
        
        return convertTicketToDTO(ticket);
    }
    
    /**
     * Update ticket status
     */
    public SupportTicketDTO updateTicketStatus(Long ticketId, SupportTicketStatus newStatus) {
        SupportTicket ticket = supportTicketRepository.findById(ticketId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Support Ticket", "id", ticketId)
                );
        
        ticket.setStatus(newStatus);
        
        if (newStatus == SupportTicketStatus.RESOLVED) {
            ticket.setResolvedAt(LocalDateTime.now());
        }
        
        ticket = supportTicketRepository.save(ticket);
        
        return convertTicketToDTO(ticket);
    }
    
    /**
     * Assign ticket to support staff
     */
    public SupportTicketDTO assignTicket(Long ticketId, Long staffId) {
        SupportTicket ticket = supportTicketRepository.findById(ticketId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Support Ticket", "id", ticketId)
                );
        
        User staff = userRepository.findById(staffId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Staff", "id", staffId)
                );
        
        if (staff.getRole() != UserRole.SUPPORT && staff.getRole() != UserRole.ADMIN) {
            throw new IllegalArgumentException("Only support staff can be assigned tickets");
        }
        
        ticket.setAssignedTo(staff);
        ticket.setStatus(SupportTicketStatus.IN_PROGRESS);
        ticket = supportTicketRepository.save(ticket);
        
        return convertTicketToDTO(ticket);
    }
    
    /**
     * Get user's support tickets
     */
    public Page<SupportTicketDTO> getUserTickets(Long userId, Pageable pageable) {
        return supportTicketRepository.findByUserId(userId, pageable)
                .map(this::convertTicketToDTO);
    }
    
    /**
     * Get tickets by status
     */
    public Page<SupportTicketDTO> getTicketsByStatus(SupportTicketStatus status, Pageable pageable) {
        return supportTicketRepository.findByStatus(status, pageable)
                .map(this::convertTicketToDTO);
    }
    
    /**
     * Get tickets assigned to staff
     */
    public Page<SupportTicketDTO> getAssignedToStaff(Long staffId, Pageable pageable) {
        return supportTicketRepository.findByAssignedToId(staffId, pageable)
                .map(this::convertTicketToDTO);
    }
    
    /**
     * Get unassigned tickets
     */
    public java.util.List<SupportTicketDTO> getUnassignedTickets() {
        return supportTicketRepository.findUnassignedTickets().stream()
                .map(this::convertTicketToDTO)
                .toList();
    }
    
    /**
     * Helper method to convert SupportTicket to SupportTicketDTO
     */
    private SupportTicketDTO convertTicketToDTO(SupportTicket ticket) {
        return SupportTicketDTO.builder()
                .id(ticket.getId())
                .userId(ticket.getUser().getId())
                .userName(ticket.getUser().getName())
                .assignedToId(ticket.getAssignedTo() != null ? ticket.getAssignedTo().getId() : null)
                .assignedToName(ticket.getAssignedTo() != null ? ticket.getAssignedTo().getName() : null)
                .title(ticket.getTitle())
                .description(ticket.getDescription())
                .status(ticket.getStatus().toString())
                .category(ticket.getCategory())
                .priority(ticket.getPriority())
                .createdAt(ticket.getCreatedAt())
                .updatedAt(ticket.getUpdatedAt())
                .resolvedAt(ticket.getResolvedAt())
                .build();
    }
}
