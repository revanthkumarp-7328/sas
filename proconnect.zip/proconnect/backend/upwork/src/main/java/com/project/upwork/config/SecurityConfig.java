package com.project.upwork.config;

import com.project.upwork.security.CustomUserDetailsService;
import com.project.upwork.security.JwtAuthenticationFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

/**
 * Spring Security Configuration
 * Configures JWT-based authentication and authorization
 */
@Configuration
@EnableWebSecurity
@EnableMethodSecurity(prePostEnabled = true)
public class SecurityConfig {
    
    private final CustomUserDetailsService customUserDetailsService;
    
    public SecurityConfig(CustomUserDetailsService customUserDetailsService) {
        this.customUserDetailsService = customUserDetailsService;
    }
    
    /**
     * Create JWT Authentication Filter Bean
     */
    @Bean
    public JwtAuthenticationFilter jwtAuthenticationFilter() {
        return new JwtAuthenticationFilter();
    }
    
    /**
     * DAO Authentication Provider
     */
    @Bean
    public DaoAuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider(customUserDetailsService);
        authProvider.setPasswordEncoder(passwordEncoder());
        return authProvider;
    }
    
    /**
     * Authentication Manager Bean
     */
    @Bean
    public AuthenticationManager authenticationManager() {
        return new ProviderManager(authenticationProvider());
    }
    
    /**
     * Password Encoder Bean - BCrypt
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
    
    /**
     * Security Filter Chain
     * Configures URL access rules, CORS, CSRF, session management
     */
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .authenticationProvider(authenticationProvider())
                // Enable CORS using the application CORS configuration
                .cors(Customizer.withDefaults())
                // Disable CSRF for stateless JWT authentication
                .csrf(csrf -> csrf.disable())
                
                // Set session management to stateless (no server sessions)
                .sessionManagement(session ->
                        session.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                )
                
                // Configure endpoint security
                .authorizeHttpRequests(authz ->
                        authz
                                // Public endpoints
                                .requestMatchers("/", "/index.html").permitAll()
                                
                                // Auth endpoints - MUST be FIRST and permitAll
                                .requestMatchers("/api/auth/register").permitAll()
                                .requestMatchers("/api/auth/login").permitAll()
                                .requestMatchers("/api/public/**").permitAll()
                                
                                // Swagger/OpenAPI endpoints
                                .requestMatchers("/swagger-ui/**", "/v3/api-docs/**").permitAll()
                                
                                // Health check
                                .requestMatchers("/actuator/health").permitAll()
                                
                                // Professional endpoints (public read)
                                .requestMatchers(HttpMethod.GET, "/api/professionals/**").permitAll()
                                .requestMatchers(HttpMethod.GET, "/api/services/**").permitAll()
                                
                                // Admin test endpoint - public
                                .requestMatchers("/api/admin/test").permitAll()
                                
                                // Protected endpoints - require authentication
                                .requestMatchers("/api/users/**").authenticated()
                                .requestMatchers("/api/bookings/**").authenticated()
                                .requestMatchers("/api/reviews/**").authenticated()
                                .requestMatchers("/api/support/**").authenticated()
                                
                                // Admin endpoints - require ADMIN role
                                .requestMatchers("/api/admin/**").hasRole("ADMIN")
                                
                                // All other requests require authentication
                                .anyRequest().authenticated()
                )
                
                // Exception handling
                .exceptionHandling(exc ->
                        exc
                                .authenticationEntryPoint((request, response, authException) -> {
                                    response.sendError(401, "Unauthorized");
                                })
                                .accessDeniedHandler((request, response, accessDeniedException) -> {
                                    response.sendError(403, "Forbidden");
                                })
                )
                
                // Add JWT authentication filter
                .addFilterBefore(jwtAuthenticationFilter(),
                        UsernamePasswordAuthenticationFilter.class);
        
        return http.build();
    }
}
