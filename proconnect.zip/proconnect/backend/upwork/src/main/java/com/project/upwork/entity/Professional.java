package com.project.upwork.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Set;

/**
 * Professional Entity - Extends User for professional-specific data
 * Uses Foreign Key relationship (1-to-1) with User
 * A professional is always a user with role PROFESSIONAL
 */
@Entity
@Table(name = "professionals", indexes = {
    @Index(name = "idx_location", columnList = "location"),
    @Index(name = "idx_verification_status", columnList = "verification_status"),
    @Index(name = "idx_rating", columnList = "total_rating")
})
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Professional {
    
    @Id
    private Long id;
    
    @OneToOne
    @MapsId
    @JoinColumn(name = "id", nullable = false)
    @JsonIgnore
    private User user;
    
    @Column(columnDefinition = "TEXT")
    private String bio;
    
    @Column(precision = 10, scale = 2)
    private BigDecimal hourlyRate;
    
    @Column(length = 255)
    private String location;
    
    @Column(precision = 3, scale = 2)
    @Builder.Default
    private BigDecimal totalRating = BigDecimal.ZERO;
    
    @Column
    @Builder.Default
    private Integer ratingCount = 0;
    
    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    @Builder.Default
    private VerificationStatus verificationStatus = VerificationStatus.PENDING;
    
    @Column
    private Integer yearsOfExperience;
    
    @Column(length = 255)
    private String bankAccount;
    
    @Column(precision = 15, scale = 2)
    @Builder.Default
    private BigDecimal totalEarnings = BigDecimal.ZERO;
    
    @Column(nullable = false, updatable = false)
    @Builder.Default
    private LocalDateTime createdAt = LocalDateTime.now();
    
    // Relationships
    @OneToMany(mappedBy = "professional", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIgnore
    private Set<Application> applications;
    
    @OneToMany(mappedBy = "professional", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIgnore
    private Set<Review> reviewsReceived;
    
    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
    }
}
