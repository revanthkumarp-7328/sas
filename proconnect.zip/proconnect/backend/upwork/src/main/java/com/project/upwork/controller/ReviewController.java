package com.project.upwork.controller;

import com.project.upwork.dto.ReviewDTO;
import com.project.upwork.dto.CreateReviewRequestDTO;
import com.project.upwork.service.ReviewService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

/**
 * Review Controller
 * Handles review creation and retrieval
 */
@RestController
@RequestMapping("/api/reviews")
@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:5173", "http://localhost:8080"})
public class ReviewController {
    
    @Autowired
    private ReviewService reviewService;
    
    /**
     * Get review by ID
     * GET /api/reviews/{reviewId}
     */
    @GetMapping("/{reviewId}")
    public ResponseEntity<?> getReviewById(@PathVariable Long reviewId) {
        try {
            ReviewDTO review = reviewService.getReviewById(reviewId);
            return new ResponseEntity<>(review, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }
    
    /**
     * Create new review
     * POST /api/reviews
     */
    @PostMapping
    public ResponseEntity<?> createReview(@Valid @RequestBody CreateReviewRequestDTO request) {
        try {
            ReviewDTO review = reviewService.createReview(
                    request.getApplicationId(),
                    request.getRating(),
                    request.getComment()
            );
            return new ResponseEntity<>(review, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
    
    /**
     * Get all reviews for a professional
     * GET /api/reviews/professional/{professionalId}?page={page}&size={size}
     */
    @GetMapping("/professional/{professionalId}")
    public ResponseEntity<?> getProfessionalReviews(
            @PathVariable Long professionalId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        try {
            Pageable pageable = PageRequest.of(page, size);
            Page<ReviewDTO> reviews = reviewService.getProfessionalReviews(professionalId, pageable);
            return new ResponseEntity<>(reviews, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
    
    /**
     * Get review for an application
     * GET /api/reviews/application/{applicationId}
     */
    @GetMapping("/application/{applicationId}")
    public ResponseEntity<?> getReviewByApplicationId(@PathVariable Long applicationId) {
        try {
            ReviewDTO review = reviewService.getReviewByApplicationId(applicationId);
            return new ResponseEntity<>(review, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }
    
    /**
     * Get professional's average rating
     * GET /api/reviews/rating/professional/{professionalId}
     */
    @GetMapping("/rating/professional/{professionalId}")
    public ResponseEntity<?> getProfessionalAverageRating(@PathVariable Long professionalId) {
        try {
            BigDecimal avgRating = reviewService.getProfessionalAverageRating(professionalId);
            return new ResponseEntity<>(avgRating, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
    
    /**
     * Get professional's review count
     * GET /api/reviews/count/professional/{professionalId}
     */
    @GetMapping("/count/professional/{professionalId}")
    public ResponseEntity<?> getProfessionalReviewCount(@PathVariable Long professionalId) {
        try {
            Long reviewCount = reviewService.getProfessionalReviewCount(professionalId);
            return new ResponseEntity<>(reviewCount, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
}
