package com.project.upwork.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;
import java.math.BigDecimal;

/**
 * Create Professional Request DTO
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CreateProfessionalRequestDTO {
    
    @NotBlank(message = "Bio is required")
    private String bio;
    
    @Positive(message = "Hourly rate must be positive")
    private BigDecimal hourlyRate;
    
    @NotBlank(message = "Location is required")
    private String location;
    
    private Integer yearsOfExperience;
    
    private String bankAccount;
}
