package com.project.upwork.controller;

import com.project.upwork.dto.ProfessionalDTO;
import com.project.upwork.dto.CreateProfessionalRequestDTO;
import com.project.upwork.service.ProfessionalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

/**
 * Professional Controller
 * Handles professional profile operations and searches
 */
@RestController
@RequestMapping("/api/professionals")
@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:5173", "http://localhost:8080"})
public class ProfessionalController {
    
    @Autowired
    private ProfessionalService professionalService;
    
    /**
     * Get professional by ID
     * GET /api/professionals/{professionalId}
     */
    @GetMapping("/{professionalId}")
    public ResponseEntity<?> getProfessionalById(@PathVariable Long professionalId) {
        try {
            ProfessionalDTO professional = professionalService.getProfessionalById(professionalId);
            return new ResponseEntity<>(professional, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }
    
    /**
     * Update professional profile
     * PUT /api/professionals/{professionalId}
     */
    @PutMapping("/{professionalId}")
    public ResponseEntity<?> updateProfessional(@PathVariable Long professionalId, 
                                                @RequestBody CreateProfessionalRequestDTO updateRequest) {
        try {
            ProfessionalDTO professional = professionalService.updateProfessional(professionalId, updateRequest);
            return new ResponseEntity<>(professional, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
    
    /**
     * Get all verified professionals
     * GET /api/professionals?page={page}&size={size}
     */
    @GetMapping
    public ResponseEntity<?> getAllVerifiedProfessionals(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        try {
            Pageable pageable = PageRequest.of(page, size);
            Page<ProfessionalDTO> professionals = professionalService.getAllVerifiedProfessionals(pageable);
            return new ResponseEntity<>(professionals, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
    
    /**
     * Search professionals by location
     * GET /api/professionals/search/location?location={location}&page={page}&size={size}
     */
    @GetMapping("/search/location")
    public ResponseEntity<?> searchByLocation(
            @RequestParam String location,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        try {
            Pageable pageable = PageRequest.of(page, size);
            Page<ProfessionalDTO> professionals = professionalService.searchByLocation(location, pageable);
            return new ResponseEntity<>(professionals, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
    
    /**
     * Search professionals by name
     * GET /api/professionals/search/name?name={name}&page={page}&size={size}
     */
    @GetMapping("/search/name")
    public ResponseEntity<?> searchByName(
            @RequestParam String name,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        try {
            Pageable pageable = PageRequest.of(page, size);
            Page<ProfessionalDTO> professionals = professionalService.searchByName(name, pageable);
            return new ResponseEntity<>(professionals, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
    
    /**
     * Search professionals by location and rating
     * GET /api/professionals/search/location-rating?location={location}&minRating={minRating}&page={page}&size={size}
     */
    @GetMapping("/search/location-rating")
    public ResponseEntity<?> searchByLocationAndRating(
            @RequestParam String location,
            @RequestParam BigDecimal minRating,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        try {
            Pageable pageable = PageRequest.of(page, size);
            Page<ProfessionalDTO> professionals = professionalService.searchByLocationAndRating(location, minRating, pageable);
            return new ResponseEntity<>(professionals, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
    
    /**
     * Get top rated professionals
     * GET /api/professionals/top?limit={limit}
     */
    @GetMapping("/top")
    public ResponseEntity<?> getTopRatedProfessionals(@RequestParam(defaultValue = "5") int limit) {
        try {
            java.util.List<ProfessionalDTO> professionals = professionalService.getTopRatedProfessionals(limit);
            return new ResponseEntity<>(professionals, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
    
    /**
     * Get current professional profile
     * GET /api/professionals/profile/me
     */
    @GetMapping("/profile/me")
    public ResponseEntity<?> getCurrentProfessionalProfile() {
        try {
            ProfessionalDTO professional = professionalService.getCurrentProfessional();
            return new ResponseEntity<>(professional, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.UNAUTHORIZED);
        }
    }
}
