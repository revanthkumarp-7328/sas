package com.project.upwork.controller;

import com.project.upwork.dto.UserDTO;
import com.project.upwork.dto.ProfessionalDTO;
import com.project.upwork.dto.JobDTO;
import com.project.upwork.dto.CreateJobRequestDTO;
import com.project.upwork.service.AdminService;
import com.project.upwork.service.JobService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Admin Controller
 * Handles admin operations like approvals, user management, and analytics
 */
@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:5173", "http://localhost:8080"})
public class AdminController {
    
    @Autowired
    private AdminService adminService;
    
    @Autowired
    private JobService jobService;

    @GetMapping("/test")
    public String testAdminEndpoint(){
        return("Admin endpoint is working!");
    }
    
    /**
     * Get all users
     * GET /api/admin/users?page={page}&size={size}
     */
    @GetMapping("/users")
    public ResponseEntity<?> getAllUsers(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        try {
            Pageable pageable = PageRequest.of(page, size);
            Page<UserDTO> users = adminService.getAllUsers(pageable);
            return new ResponseEntity<>(users, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
    
    /**
     * Get pending professional verifications
     * GET /api/admin/professionals/pending
     */
    @GetMapping("/professionals/pending")
    public ResponseEntity<?> getPendingVerifications() {
        try {
            List<ProfessionalDTO> professionals = adminService.getPendingVerifications();
            return new ResponseEntity<>(professionals, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
    
    /**
     * Approve professional verification
     * POST /api/admin/professionals/{professionalId}/approve
     */
    @PostMapping("/professionals/{professionalId}/approve")
    public ResponseEntity<?> approveProfessional(@PathVariable Long professionalId) {
        try {
            ProfessionalDTO professional = adminService.approveProfessional(professionalId);
            return new ResponseEntity<>(professional, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
    
    /**
     * Reject professional verification
     * POST /api/admin/professionals/{professionalId}/reject
     */
    @PostMapping("/professionals/{professionalId}/reject")
    public ResponseEntity<?> rejectProfessional(@PathVariable Long professionalId) {
        try {
            ProfessionalDTO professional = adminService.rejectProfessional(professionalId);
            return new ResponseEntity<>(professional, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
    
    /**
     * Suspend user account
     * POST /api/admin/users/{userId}/suspend
     */
    @PostMapping("/users/{userId}/suspend")
    public ResponseEntity<?> suspendUser(@PathVariable Long userId) {
        try {
            UserDTO user = adminService.suspendUser(userId);
            return new ResponseEntity<>(user, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
    
    /**
     * Activate user account
     * POST /api/admin/users/{userId}/activate
     */
    @PostMapping("/users/{userId}/activate")
    public ResponseEntity<?> activateUser(@PathVariable Long userId) {
        try {
            UserDTO user = adminService.activateUser(userId);
            return new ResponseEntity<>(user, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
    
    /**
     * Create a new job posting (admin)
     * POST /api/admin/jobs
     */
    @PostMapping("/jobs")
    public ResponseEntity<?> createJob(@RequestBody CreateJobRequestDTO request) {
        try {
            // Admin creates job on behalf of a user, but for now, assume admin user or specify userId
            // For simplicity, create as admin user, but ideally pass userId
            JobDTO job = jobService.createJob(request, 1L); // Assuming admin user ID is 1
            return new ResponseEntity<>(job, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
    
    /**
     * Deactivate job posting
     * DELETE /api/admin/jobs/{jobId}
     */
    @DeleteMapping("/jobs/{jobId}")
    public ResponseEntity<?> deactivateJob(@PathVariable Long jobId) {
        try {
            JobDTO job = adminService.deactivateJob(jobId);
            return new ResponseEntity<>(job, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
    
    /**
     * Get dashboard analytics
     * GET /api/admin/dashboard/analytics
     */
    @GetMapping("/dashboard/analytics")
    public ResponseEntity<?> getDashboardAnalytics() {
        try {
            Object analytics = adminService.getDashboardAnalytics();
            return new ResponseEntity<>(analytics, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
    
    /**
     * Get all applications (paginated)
     * GET /api/admin/applications?page={page}&size={size}
     */
    @GetMapping("/applications")
    public ResponseEntity<?> getAllApplications(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        try {
            Pageable pageable = PageRequest.of(page, size);
            Page<Object> applications = adminService.getAllApplications(pageable);
            return new ResponseEntity<>(applications, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
    
    /**
     * Get all support tickets (paginated)
     * GET /api/admin/support-tickets?page={page}&size={size}
     */
    @GetMapping("/support-tickets")
    public ResponseEntity<?> getAllSupportTickets(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        try {
            Pageable pageable = PageRequest.of(page, size);
            Page<Object> tickets = adminService.getAllSupportTickets(pageable);
            return new ResponseEntity<>(tickets, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
}
