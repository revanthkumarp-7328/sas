package com.project.upwork.service;

import com.project.upwork.dto.UserDTO;
import com.project.upwork.entity.User;
import com.project.upwork.entity.UserRole;
import com.project.upwork.exception.ResourceNotFoundException;
import com.project.upwork.exception.UnauthorizedException;
import com.project.upwork.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * User Service
 * Handles user profile management, search, and updates
 */
@Service
@Transactional
public class UserService {
    
    @Autowired
    private UserRepository userRepository;
    
    /**
     * Get user by ID
     */
    public UserDTO getUserById(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("User", "id", userId)
                );
        
        return convertUserToDTO(user);
    }
    
    /**
     * Get user by email
     */
    public UserDTO getUserByEmail(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() ->
                        new ResourceNotFoundException("User", "email", email)
                );
        
        return convertUserToDTO(user);
    }
    
    /**
     * Update user profile
     */
    public UserDTO updateUser(Long userId, UserDTO updateRequest) {
        // Verify authorization (user can only update their own profile)
        String currentUserEmail = SecurityContextHolder.getContext()
                .getAuthentication().getName();
        User currentUser = userRepository.findByEmail(currentUserEmail)
                .orElseThrow(() ->
                        new ResourceNotFoundException("User", "email", currentUserEmail)
                );
        
        if (!currentUser.getId().equals(userId)) {
            throw new UnauthorizedException("You can only update your own profile");
        }
        
        // Get user to update
        User user = userRepository.findById(userId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("User", "id", userId)
                );
        
        // Update allowed fields
        if (updateRequest.getName() != null && !updateRequest.getName().isEmpty()) {
            user.setName(updateRequest.getName());
        }
        
        if (updateRequest.getPhone() != null && !updateRequest.getPhone().isEmpty()) {
            user.setPhone(updateRequest.getPhone());
        }
        
        if (updateRequest.getProfilePictureUrl() != null && !updateRequest.getProfilePictureUrl().isEmpty()) {
            user.setProfilePictureUrl(updateRequest.getProfilePictureUrl());
        }
        
        user = userRepository.save(user);
        
        return convertUserToDTO(user);
    }
    
    /**
     * Search users by name
     */
    public Page<UserDTO> searchUsers(String name, Pageable pageable) {
        // Only accessible to admin or the user themselves
        List<User> users = userRepository.searchByName(name);
        // Convert List to Page based on pageable
        int start = (int) pageable.getOffset();
        int end = Math.min(start + pageable.getPageSize(), users.size());
        List<User> pageContent = users.subList(start, end);
        return new org.springframework.data.domain.PageImpl<>(
                pageContent.stream().map(this::convertUserToDTO).toList(),
                pageable,
                users.size()
        );
    }
    
    /**
     * Get all professionals (public endpoint)
     */
    public Page<UserDTO> getAllProfessionals(Pageable pageable) {
        return userRepository.findByRole(UserRole.PROFESSIONAL, pageable)
                .map(this::convertUserToDTO);
    }
    
    /**
     * Deactivate user account
     */
    public void deactivateUser(Long userId) {
        // Verify authorization
        String currentUserEmail = SecurityContextHolder.getContext()
                .getAuthentication().getName();
        User currentUser = userRepository.findByEmail(currentUserEmail)
                .orElseThrow(() ->
                        new ResourceNotFoundException("User", "email", currentUserEmail)
                );
        
        if (!currentUser.getId().equals(userId)) {
            throw new UnauthorizedException("You can only deactivate your own account");
        }
        
        User user = userRepository.findById(userId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("User", "id", userId)
                );
        
        user.setIsActive(false);
        userRepository.save(user);
    }
    
    /**
     * Get current authenticated user
     */
    public UserDTO getCurrentUser() {
        String email = SecurityContextHolder.getContext()
                .getAuthentication().getName();
        
        return getUserByEmail(email);
    }
    
    /**
     * Helper method to convert User to UserDTO
     */
    private UserDTO convertUserToDTO(User user) {
        return UserDTO.builder()
                .id(user.getId())
                .email(user.getEmail())
                .name(user.getName())
                .phone(user.getPhone())
                .role(user.getRole().toString())
                .profilePictureUrl(user.getProfilePictureUrl())
                .isActive(user.getIsActive())
                .createdAt(user.getCreatedAt())
                .updatedAt(user.getUpdatedAt())
                .build();
    }
}
