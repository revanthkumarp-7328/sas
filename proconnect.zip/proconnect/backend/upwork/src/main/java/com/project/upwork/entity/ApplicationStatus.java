package com.project.upwork.entity;

/**
 * Application Status Enumeration
 * Represents the lifecycle of a job application
 */
public enum ApplicationStatus {
    PENDING,    // Application submitted, awaiting review
    ACCEPTED,   // Application accepted by job poster
    REJECTED,   // Application rejected by job poster
    WITHDRAWN   // Application withdrawn by professional
}