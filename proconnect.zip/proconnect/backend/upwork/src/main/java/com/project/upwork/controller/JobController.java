package com.project.upwork.controller;

import com.project.upwork.dto.CreateJobRequestDTO;
import com.project.upwork.dto.JobDTO;
import com.project.upwork.entity.JobStatus;
import com.project.upwork.service.JobService;
import com.project.upwork.security.JwtTokenProvider;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;

/**
 * Job Controller - REST endpoints for job management
 */
@RestController
@RequestMapping("/api/jobs")
@RequiredArgsConstructor
public class JobController {

    private final JobService jobService;
    private final JwtTokenProvider jwtTokenProvider;

    /**
     * Create a new job posting
     */
    @PostMapping
    public ResponseEntity<JobDTO> createJob(
            @Valid @RequestBody CreateJobRequestDTO request,
            @RequestHeader("Authorization") String token) {

        Long userId = Long.valueOf(jwtTokenProvider.getUserIdFromToken(token.replace("Bearer ", "")));
        JobDTO job = jobService.createJob(request, userId);
        return ResponseEntity.ok(job);
    }

    /**
     * Get job by ID
     */
    @GetMapping("/{jobId}")
    public ResponseEntity<JobDTO> getJob(@PathVariable Long jobId) {
        JobDTO job = jobService.getJobById(jobId);
        return ResponseEntity.ok(job);
    }

    /**
     * Get jobs posted by current user
     */
    @GetMapping("/my-jobs")
    public ResponseEntity<Page<JobDTO>> getMyJobs(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestHeader("Authorization") String token) {

        Long userId = Long.valueOf(jwtTokenProvider.getUserIdFromToken(token.replace("Bearer ", "")));
        Pageable pageable = PageRequest.of(page, size);
        Page<JobDTO> jobs = jobService.getJobsByUser(userId, pageable);
        return ResponseEntity.ok(jobs);
    }

    /**
     * Get open jobs (available for applications)
     */
    @GetMapping("/open")
    public ResponseEntity<Page<JobDTO>> getOpenJobs(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        Pageable pageable = PageRequest.of(page, size);
        Page<JobDTO> jobs = jobService.getOpenJobs(pageable);
        return ResponseEntity.ok(jobs);
    }

    /**
     * Search jobs
     */
    @GetMapping("/search")
    public ResponseEntity<Page<JobDTO>> searchJobs(
            @RequestParam String keyword,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        Pageable pageable = PageRequest.of(page, size);
        Page<JobDTO> jobs = jobService.searchJobs(keyword, pageable);
        return ResponseEntity.ok(jobs);
    }

    /**
     * Update job status
     */
    @PatchMapping("/{jobId}/status")
    public ResponseEntity<JobDTO> updateJobStatus(
            @PathVariable Long jobId,
            @RequestParam JobStatus status,
            @RequestHeader("Authorization") String token) {

        Long userId = Long.valueOf(jwtTokenProvider.getUserIdFromToken(token.replace("Bearer ", "")));
        JobDTO job = jobService.updateJobStatus(jobId, status, userId);
        return ResponseEntity.ok(job);
    }

    /**
     * Delete job
     */
    @DeleteMapping("/{jobId}")
    public ResponseEntity<Void> deleteJob(
            @PathVariable Long jobId,
            @RequestHeader("Authorization") String token) {

        Long userId = Long.valueOf(jwtTokenProvider.getUserIdFromToken(token.replace("Bearer ", "")));
        jobService.deleteJob(jobId, userId);
        return ResponseEntity.noContent().build();
    }
}