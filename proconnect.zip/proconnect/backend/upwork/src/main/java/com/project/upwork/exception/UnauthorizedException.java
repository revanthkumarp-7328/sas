package com.project.upwork.exception;

/**
 * Unauthorized Exception
 * Thrown when user doesn't have permission for an action
 */
public class UnauthorizedException extends RuntimeException {
    public UnauthorizedException(String message) {
        super(message);
    }
}
