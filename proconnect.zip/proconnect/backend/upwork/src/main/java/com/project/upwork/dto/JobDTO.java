package com.project.upwork.dto;

import com.project.upwork.entity.JobStatus;
import com.project.upwork.entity.JobType;
import com.project.upwork.entity.Urgency;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Job DTO - Data Transfer Object for Job entity
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class JobDTO {

    private Long id;
    private Long userId;
    private String userName;
    private String title;
    private String description;
    private String category;
    private String location;
    private BigDecimal budgetMin;
    private BigDecimal budgetMax;
    private JobType jobType;
    private Integer durationHours;
    private Urgency urgency;
    private JobStatus status;
    private String requiredSkills;
    private String preferredExperience;
    private String attachments;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private Integer applicationCount;
}