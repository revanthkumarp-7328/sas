package com.project.upwork.repository;

import com.project.upwork.entity.SupportTicket;
import com.project.upwork.entity.SupportTicketStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Support Ticket Repository - Data access layer for SupportTicket entity
 */
@Repository
public interface SupportTicketRepository extends JpaRepository<SupportTicket, Long> {
    
    /**
     * Find all support tickets created by a user
     */
    List<SupportTicket> findByUserId(Long userId);
    
    /**
     * Find user's support tickets with pagination
     */
    Page<SupportTicket> findByUserId(Long userId, Pageable pageable);
    
    /**
     * Find support tickets by status
     */
    List<SupportTicket> findByStatus(SupportTicketStatus status);
    
    /**
     * Find support tickets by status with pagination
     */
    Page<SupportTicket> findByStatus(SupportTicketStatus status, Pageable pageable);
    
    /**
     * Find support tickets assigned to a support staff
     */
    List<SupportTicket> findByAssignedToId(Long assignedToId);
    
    /**
     * Find support tickets assigned to staff with pagination
     */
    Page<SupportTicket> findByAssignedToId(Long assignedToId, Pageable pageable);
    
    /**
     * Find unassigned tickets
     */
    @Query("SELECT st FROM SupportTicket st WHERE st.assignedTo IS NULL ORDER BY st.priority ASC, st.createdAt ASC")
    List<SupportTicket> findUnassignedTickets();
    
    /**
     * Find high priority tickets
     */
    List<SupportTicket> findByPriority(Integer priority);
    
    /**
     * Find open tickets sorted by priority
     */
    @Query("SELECT st FROM SupportTicket st WHERE st.status = 'OPEN' ORDER BY st.priority ASC, st.createdAt ASC")
    List<SupportTicket> findOpenTicketsByPriority();
    
    /**
     * Find tickets by category
     */
    List<SupportTicket> findByCategory(String category);
    
    /**
     * Count open tickets for a support staff
     */
    @Query("SELECT COUNT(st) FROM SupportTicket st WHERE st.assignedTo.id = :staffId AND st.status = 'OPEN'")
    Long countOpenTicketsForStaff(@Param("staffId") Long staffId);
}
