package com.project.upwork.controller;

import com.project.upwork.dto.SupportTicketDTO;
import com.project.upwork.dto.CreateSupportTicketRequestDTO;
import com.project.upwork.entity.SupportTicketStatus;
import com.project.upwork.service.SupportService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Support Controller
 * Handles support ticket management
 */
@RestController
@RequestMapping("/api/support")
@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:5173", "http://localhost:8080"})
public class SupportController {
    
    @Autowired
    private SupportService supportService;
    
    /**
     * Get ticket by ID
     * GET /api/support/{ticketId}
     */
    @GetMapping("/{ticketId}")
    public ResponseEntity<?> getTicketById(@PathVariable Long ticketId) {
        try {
            SupportTicketDTO ticket = supportService.getTicketById(ticketId);
            return new ResponseEntity<>(ticket, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }
    
    /**
     * Create support ticket
     * POST /api/support
     */
    @PostMapping
    public ResponseEntity<?> createTicket(@Valid @RequestBody CreateSupportTicketRequestDTO request) {
        try {
            SupportTicketDTO ticket = supportService.createTicket(
                    request.getUserId(),
                    request.getTitle(),
                    request.getDescription(),
                    request.getCategory(),
                    request.getPriority()
            );
            return new ResponseEntity<>(ticket, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
    
    /**
     * Update ticket status
     * PATCH /api/support/{ticketId}/status
     */
    @PatchMapping("/{ticketId}/status")
    public ResponseEntity<?> updateTicketStatus(
            @PathVariable Long ticketId,
            @RequestParam SupportTicketStatus status) {
        try {
            SupportTicketDTO ticket = supportService.updateTicketStatus(ticketId, status);
            return new ResponseEntity<>(ticket, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
    
    /**
     * Assign ticket to support staff
     * POST /api/support/{ticketId}/assign
     */
    @PostMapping("/{ticketId}/assign")
    public ResponseEntity<?> assignTicket(
            @PathVariable Long ticketId,
            @RequestParam Long staffId) {
        try {
            SupportTicketDTO ticket = supportService.assignTicket(ticketId, staffId);
            return new ResponseEntity<>(ticket, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
    
    /**
     * Get user's support tickets
     * GET /api/support/user/{userId}?page={page}&size={size}
     */
    @GetMapping("/user/{userId}")
    public ResponseEntity<?> getUserTickets(
            @PathVariable Long userId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        try {
            Pageable pageable = PageRequest.of(page, size);
            Page<SupportTicketDTO> tickets = supportService.getUserTickets(userId, pageable);
            return new ResponseEntity<>(tickets, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
    
    /**
     * Get tickets by status
     * GET /api/support/status?status={status}&page={page}&size={size}
     */
    @GetMapping("/status")
    public ResponseEntity<?> getTicketsByStatus(
            @RequestParam SupportTicketStatus status,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        try {
            Pageable pageable = PageRequest.of(page, size);
            Page<SupportTicketDTO> tickets = supportService.getTicketsByStatus(status, pageable);
            return new ResponseEntity<>(tickets, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
    
    /**
     * Get tickets assigned to staff
     * GET /api/support/assigned/{staffId}?page={page}&size={size}
     */
    @GetMapping("/assigned/{staffId}")
    public ResponseEntity<?> getAssignedToStaff(
            @PathVariable Long staffId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        try {
            Pageable pageable = PageRequest.of(page, size);
            Page<SupportTicketDTO> tickets = supportService.getAssignedToStaff(staffId, pageable);
            return new ResponseEntity<>(tickets, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
    
    /**
     * Get unassigned tickets
     * GET /api/support/unassigned
     */
    @GetMapping("/unassigned")
    public ResponseEntity<?> getUnassignedTickets() {
        try {
            List<SupportTicketDTO> tickets = supportService.getUnassignedTickets();
            return new ResponseEntity<>(tickets, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
}
