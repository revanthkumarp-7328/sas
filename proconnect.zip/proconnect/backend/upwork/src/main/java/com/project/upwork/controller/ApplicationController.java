package com.project.upwork.controller;

import com.project.upwork.dto.ApplicationDTO;
import com.project.upwork.dto.CreateApplicationRequestDTO;
import com.project.upwork.entity.ApplicationStatus;
import com.project.upwork.service.ApplicationService;
import com.project.upwork.security.JwtTokenProvider;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;

/**
 * Application Controller - REST endpoints for job applications
 */
@RestController
@RequestMapping("/api/applications")
@RequiredArgsConstructor
public class ApplicationController {

    private final ApplicationService applicationService;
    private final JwtTokenProvider jwtTokenProvider;

    /**
     * Apply to a job
     */
    @PostMapping
    public ResponseEntity<ApplicationDTO> createApplication(
            @Valid @RequestBody CreateApplicationRequestDTO request,
            @RequestHeader("Authorization") String token) {

        Long professionalId = Long.valueOf(jwtTokenProvider.getUserIdFromToken(token.replace("Bearer ", "")));
        ApplicationDTO application = applicationService.createApplication(request, professionalId);
        return ResponseEntity.ok(application);
    }

    /**
     * Get application by ID
     */
    @GetMapping("/{applicationId}")
    public ResponseEntity<ApplicationDTO> getApplication(@PathVariable Long applicationId) {
        ApplicationDTO application = applicationService.getApplicationById(applicationId);
        return ResponseEntity.ok(application);
    }

    /**
     * Get applications for a job (job owner only)
     */
    @GetMapping("/job/{jobId}")
    public ResponseEntity<Page<ApplicationDTO>> getApplicationsByJob(
            @PathVariable Long jobId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestHeader("Authorization") String token) {

        Long userId = Long.valueOf(jwtTokenProvider.getUserIdFromToken(token.replace("Bearer ", "")));
        Pageable pageable = PageRequest.of(page, size);
        Page<ApplicationDTO> applications = applicationService.getApplicationsByJob(jobId, userId, pageable);
        return ResponseEntity.ok(applications);
    }

    /**
     * Get applications by current professional
     */
    @GetMapping("/my-applications")
    public ResponseEntity<Page<ApplicationDTO>> getMyApplications(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestHeader("Authorization") String token) {

        Long professionalId = Long.valueOf(jwtTokenProvider.getUserIdFromToken(token.replace("Bearer ", "")));
        Pageable pageable = PageRequest.of(page, size);
        Page<ApplicationDTO> applications = applicationService.getApplicationsByProfessional(professionalId, pageable);
        return ResponseEntity.ok(applications);
    }

    /**
     * Update application status (job owner only)
     */
    @PatchMapping("/{applicationId}/status")
    public ResponseEntity<ApplicationDTO> updateApplicationStatus(
            @PathVariable Long applicationId,
            @RequestParam ApplicationStatus status,
            @RequestHeader("Authorization") String token) {

        Long userId = Long.valueOf(jwtTokenProvider.getUserIdFromToken(token.replace("Bearer ", "")));
        ApplicationDTO application = applicationService.updateApplicationStatus(applicationId, status, userId);
        return ResponseEntity.ok(application);
    }

    /**
     * Withdraw application (professional only)
     */
    @DeleteMapping("/{applicationId}")
    public ResponseEntity<Void> withdrawApplication(
            @PathVariable Long applicationId,
            @RequestHeader("Authorization") String token) {

        Long professionalId = Long.valueOf(jwtTokenProvider.getUserIdFromToken(token.replace("Bearer ", "")));
        applicationService.withdrawApplication(applicationId, professionalId);
        return ResponseEntity.noContent().build();
    }
}