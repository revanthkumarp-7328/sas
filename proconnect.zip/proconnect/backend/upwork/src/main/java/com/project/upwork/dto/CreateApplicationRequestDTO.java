package com.project.upwork.dto;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * Create Application Request DTO - For professionals applying to jobs
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CreateApplicationRequestDTO {

    @NotNull(message = "Job ID is required")
    private Long jobId;

    private BigDecimal proposedPrice;

    private Integer proposedDuration;

    private String coverLetter;
}