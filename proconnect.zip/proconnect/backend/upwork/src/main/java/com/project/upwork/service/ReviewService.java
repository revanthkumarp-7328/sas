package com.project.upwork.service;

import com.project.upwork.dto.ReviewDTO;
import com.project.upwork.entity.*;
import com.project.upwork.exception.InvalidBookingException;
import com.project.upwork.exception.ResourceNotFoundException;
import com.project.upwork.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

/**
 * Review Service
 * Handles review creation and rating management
 */
@Service
@Transactional
public class ReviewService {
    
    @Autowired
    private ReviewRepository reviewRepository;
    
    @Autowired
    private ApplicationRepository applicationRepository;
    
    @Autowired
    private ProfessionalRepository professionalRepository;
    
    /**
     * Get review by ID
     */
    public ReviewDTO getReviewById(Long reviewId) {
        Review review = reviewRepository.findById(reviewId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Review", "id", reviewId)
                );
        
        return convertReviewToDTO(review);
    }
    
    /**
     * Create review for accepted application
     */
    public ReviewDTO createReview(Long applicationId, Integer rating, String comment) {
        Application application = applicationRepository.findById(applicationId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Application", "id", applicationId)
                );

        if (application.getStatus() != ApplicationStatus.ACCEPTED) {
            throw new InvalidBookingException("Review can only be given for accepted applications");
        }

        if (reviewRepository.findByApplicationId(applicationId).isPresent()) {
            throw new InvalidBookingException("Review already exists for this application");
        }

        if (rating < 1 || rating > 5) {
            throw new InvalidBookingException("Rating must be between 1 and 5");
        }

        Review review = Review.builder()
                .application(application)
                .user(application.getJob().getUser())
                .professional(application.getProfessional())
                .rating(rating)
                .comment(comment)
                .build();

        review = reviewRepository.save(review);

        updateProfessionalRating(application.getProfessional().getId());

        return convertReviewToDTO(review);
    }
    
    /**
     * Get all reviews for a professional
     */
    public Page<ReviewDTO> getProfessionalReviews(Long professionalId, Pageable pageable) {
        // Verify professional exists
        professionalRepository.findById(professionalId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Professional", "id", professionalId)
                );
        
        return reviewRepository.findByProfessionalId(professionalId, pageable)
                .map(this::convertReviewToDTO);
    }
    
    /**
     * Get review for application
     */
    public ReviewDTO getReviewByApplicationId(Long applicationId) {
        Review review = reviewRepository.findByApplicationId(applicationId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Review for application", "applicationId", applicationId)
                );
        
        return convertReviewToDTO(review);
    }
    
    /**
     * Update professional rating after new review
     */
    private void updateProfessionalRating(Long professionalId) {
        Professional professional = professionalRepository.findById(professionalId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Professional", "id", professionalId)
                );
        
        // Calculate new average rating
        BigDecimal avgRating = reviewRepository.calculateAverageRatingForProfessional(professionalId);
        Long reviewCount = reviewRepository.countReviewsForProfessional(professionalId);
        
        if (avgRating != null) {
            professional.setTotalRating(avgRating);
            professional.setRatingCount(reviewCount.intValue());
            professionalRepository.save(professional);
        }
    }
    
    /**
     * Get average rating for professional
     */
    public BigDecimal getProfessionalAverageRating(Long professionalId) {
        BigDecimal avgRating = reviewRepository.calculateAverageRatingForProfessional(professionalId);
        return avgRating != null ? avgRating : BigDecimal.ZERO;
    }
    
    /**
     * Get review count for professional
     */
    public Long getProfessionalReviewCount(Long professionalId) {
        return reviewRepository.countReviewsForProfessional(professionalId);
    }
    
    /**
     * Helper method to convert Review to ReviewDTO
     */
    private ReviewDTO convertReviewToDTO(Review review) {
        return ReviewDTO.builder()
                .id(review.getId())
                .applicationId(review.getApplication().getId())
                .userId(review.getUser().getId())
                .userName(review.getUser().getName())
                .professionalId(review.getProfessional().getId())
                .professionalName(review.getProfessional().getUser().getName())
                .rating(review.getRating())
                .comment(review.getComment())
                .createdAt(review.getCreatedAt())
                .build();
    }
}
