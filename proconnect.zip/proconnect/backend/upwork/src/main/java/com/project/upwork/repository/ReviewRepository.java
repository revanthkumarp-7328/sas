package com.project.upwork.repository;

import com.project.upwork.entity.Review;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

/**
 * Review Repository - Data access layer for Review entity
 */
@Repository
public interface ReviewRepository extends JpaRepository<Review, Long> {
    
    /**
     * Find all reviews for a professional
     */
    List<Review> findByProfessionalId(Long professionalId);
    
    /**
     * Find reviews for a professional with pagination
     */
    Page<Review> findByProfessionalId(Long professionalId, Pageable pageable);
    
    /**
     * Find review for a specific application
     */
    Optional<Review> findByApplicationId(Long applicationId);
    
    /**
     * Find reviews given by a user
     */
    List<Review> findByUserId(Long userId);
    
    /**
     * Calculate average rating for a professional
     */
    @Query("SELECT AVG(r.rating) FROM Review r WHERE r.professional.id = :professionalId")
    BigDecimal calculateAverageRatingForProfessional(@Param("professionalId") Long professionalId);
    
    /**
     * Count reviews for a professional
     */
    @Query("SELECT COUNT(r) FROM Review r WHERE r.professional.id = :professionalId")
    Long countReviewsForProfessional(@Param("professionalId") Long professionalId);
    
    /**
     * Find reviews with specific rating
     */
    List<Review> findByProfessionalIdAndRating(Long professionalId, Integer rating);
    
    /**
     * Find reviews with rating >= min rating
     */
    @Query("SELECT r FROM Review r WHERE r.professional.id = :professionalId AND r.rating >= :minRating")
    List<Review> findHighRatedReviews(@Param("professionalId") Long professionalId, @Param("minRating") Integer minRating);
}
