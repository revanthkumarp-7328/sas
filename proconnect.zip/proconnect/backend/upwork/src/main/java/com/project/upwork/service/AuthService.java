package com.project.upwork.service;

import com.project.upwork.dto.JwtResponseDTO;
import com.project.upwork.dto.LoginRequestDTO;
import com.project.upwork.dto.RegisterRequestDTO;
import com.project.upwork.dto.UserDTO;
import com.project.upwork.entity.Professional;
import com.project.upwork.entity.User;
import com.project.upwork.entity.UserRole;
import com.project.upwork.entity.VerificationStatus;
import com.project.upwork.exception.AuthenticationException;
import com.project.upwork.exception.DuplicateResourceException;
import com.project.upwork.exception.ResourceNotFoundException;
import com.project.upwork.repository.ProfessionalRepository;
import com.project.upwork.repository.UserRepository;
import com.project.upwork.security.JwtTokenProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Authentication Service
 * Handles user registration, login, and JWT token generation
 */
@Service
@Transactional
public class AuthService {
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private ProfessionalRepository professionalRepository;
    
    @Autowired
    private PasswordEncoder passwordEncoder;
    
    @Autowired
    private AuthenticationManager authenticationManager;
    
    @Autowired
    private JwtTokenProvider jwtTokenProvider;
    
    /**
     * Register a new user
     */
    public UserDTO register(RegisterRequestDTO registerRequest) {
        String normalizedEmail = registerRequest.getEmail().trim().toLowerCase();

        // Validate request
        if (!registerRequest.getPassword().equals(registerRequest.getConfirmPassword())) {
            throw new AuthenticationException("Passwords do not match");
        }
        
        // Check if email already exists
        if (userRepository.existsByEmail(normalizedEmail)) {
            throw new DuplicateResourceException(
                    "Email already in use: " + normalizedEmail
            );
        }
        
        // Create new user
        User user = User.builder()
                .email(normalizedEmail)
                .password(passwordEncoder.encode(registerRequest.getPassword()))
                .name(registerRequest.getName())
                .phone(registerRequest.getPhone())
                .role(registerRequest.getIsProfessional() != null && registerRequest.getIsProfessional() 
                        ? UserRole.PROFESSIONAL 
                        : UserRole.USER)
                .isActive(true)
                .build();
        
        user = userRepository.save(user);
        
        // If registering as professional, create professional profile
        if (user.getRole() == UserRole.PROFESSIONAL) {
            Professional professional = Professional.builder()
                    .user(user)
                    .verificationStatus(VerificationStatus.PENDING)
                    .build();
            
            professionalRepository.save(professional);
            user.setProfessional(professional);
            userRepository.save(user); // Save the user again to persist the relationship
        }
        
        // Convert to DTO and return (without password)
        return convertUserToDTO(user);
    }
    
    /**
     * Login user and generate JWT token
     */
    public JwtResponseDTO login(LoginRequestDTO loginRequest) {
        String normalizedEmail = loginRequest.getEmail().trim().toLowerCase();

        try {
            // Authenticate user
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(
                            normalizedEmail,
                            loginRequest.getPassword()
                    )
            );
            
            // Get authenticated user
            User user = userRepository.findByEmail(normalizedEmail)
                    .orElseThrow(() ->
                            new ResourceNotFoundException("User", "email", normalizedEmail)
                    );
            
            // Generate JWT token
            String token = jwtTokenProvider.generateToken(
                    user.getEmail(),
                    user.getId().toString(),
                    user.getRole().toString()
            );
            
            long expirationTime = jwtTokenProvider.getExpirationTime(token).getTime();
            
            // Build and return response
            return JwtResponseDTO.builder()
                    .token(token)
                    .type("Bearer")
                    .userId(user.getId())
                    .email(user.getEmail())
                    .name(user.getName())
                    .role(user.getRole().toString())
                    .expiresIn(expirationTime)
                    .build();
            
        } catch (BadCredentialsException ex) {
            throw new AuthenticationException("Invalid email or password");
        } catch (org.springframework.security.core.AuthenticationException ex) {
            throw new AuthenticationException("Authentication failed: " + ex.getMessage());
        }
    }
    
    /**
     * Get current user info (used with JWT token)
     */
    public UserDTO getCurrentUser() {
        String email = SecurityContextHolder.getContext().getAuthentication().getName();
        User user = userRepository.findByEmail(email)
                .orElseThrow(() ->
                        new ResourceNotFoundException("User", "email", email)
                );
        
        return convertUserToDTO(user);
    }
    
    /**
     * Helper method to convert User to UserDTO
     */
    private UserDTO convertUserToDTO(User user) {
        return UserDTO.builder()
                .id(user.getId())
                .email(user.getEmail())
                .name(user.getName())
                .phone(user.getPhone())
                .role(user.getRole().toString())
                .profilePictureUrl(user.getProfilePictureUrl())
                .isActive(user.getIsActive())
                .createdAt(user.getCreatedAt())
                .updatedAt(user.getUpdatedAt())
                .build();
    }
}
