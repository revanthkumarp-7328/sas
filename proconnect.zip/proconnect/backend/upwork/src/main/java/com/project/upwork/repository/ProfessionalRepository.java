package com.project.upwork.repository;

import com.project.upwork.entity.Professional;
import com.project.upwork.entity.VerificationStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

/**
 * Professional Repository - Data access layer for Professional entity
 */
@Repository
public interface ProfessionalRepository extends JpaRepository<Professional, Long> {
    
    /**
     * Find professionals by verification status
     */
    List<Professional> findByVerificationStatus(VerificationStatus status);
    
    /**
     * Find verified professionals with pagination
     */
    Page<Professional> findByVerificationStatus(VerificationStatus status, Pageable pageable);
    
    /**
     * Find professionals by location
     */
    List<Professional> findByLocation(String location);
    
    /**
     * Find professionals by location and verification status
     */
    Page<Professional> findByLocationAndVerificationStatus(String location, VerificationStatus status, Pageable pageable);
    
    /**
     * Find professionals with minimum rating
     */
    @Query("SELECT p FROM Professional p WHERE p.totalRating >= :minRating AND p.verificationStatus = 'VERIFIED'")
    List<Professional> findByMinimumRating(@Param("minRating") BigDecimal minRating);
    
    /**
     * Find top-rated professionals
     */
    @Query("SELECT p FROM Professional p WHERE p.verificationStatus = 'VERIFIED' ORDER BY p.totalRating DESC LIMIT :limit")
    List<Professional> findTopRatedProfessionals(@Param("limit") int limit);
    
    /**
     * Search professionals by name
     */
    @Query("SELECT p FROM Professional p WHERE p.verificationStatus = 'VERIFIED' AND LOWER(p.user.name) LIKE LOWER(CONCAT('%', :name, '%'))")
    Page<Professional> searchByName(@Param("name") String name, Pageable pageable);
    
    /**
     * Find professionals in a location with minimum rating (advanced search)
     */
    @Query("SELECT p FROM Professional p WHERE p.location = :location AND p.totalRating >= :minRating AND p.verificationStatus = 'VERIFIED'")
    Page<Professional> findByLocationAndMinRating(@Param("location") String location, @Param("minRating") BigDecimal minRating, Pageable pageable);
}
