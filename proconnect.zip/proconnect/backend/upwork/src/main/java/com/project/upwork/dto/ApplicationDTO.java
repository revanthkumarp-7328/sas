package com.project.upwork.dto;

import com.project.upwork.entity.ApplicationStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Application DTO - Data Transfer Object for Application entity
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ApplicationDTO {

    private Long id;
    private Long jobId;
    private String jobTitle;
    private Long professionalId;
    private String professionalName;
    private BigDecimal proposedPrice;
    private Integer proposedDuration;
    private String coverLetter;
    private ApplicationStatus status;
    private LocalDateTime appliedAt;
    private LocalDateTime updatedAt;
}