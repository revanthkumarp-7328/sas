package com.project.upwork.service;

import com.project.upwork.dto.CreateJobRequestDTO;
import com.project.upwork.dto.JobDTO;
import com.project.upwork.entity.Job;
import com.project.upwork.entity.JobStatus;
import com.project.upwork.entity.User;
import com.project.upwork.repository.JobRepository;
import com.project.upwork.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Job Service - Business logic for job management
 */
@Service
@RequiredArgsConstructor
@Transactional
public class JobService {

    private final JobRepository jobRepository;
    private final UserRepository userRepository;

    /**
     * Create a new job posting
     */
    public JobDTO createJob(CreateJobRequestDTO request, Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Job job = Job.builder()
                .user(user)
                .title(request.getTitle())
                .description(request.getDescription())
                .category(request.getCategory())
                .location(request.getLocation())
                .budgetMin(request.getBudgetMin())
                .budgetMax(request.getBudgetMax())
                .jobType(request.getJobType())
                .durationHours(request.getDurationHours())
                .urgency(request.getUrgency())
                .status(JobStatus.OPEN)
                .requiredSkills(request.getRequiredSkills())
                .preferredExperience(request.getPreferredExperience())
                .attachments(request.getAttachments())
                .build();

        Job savedJob = jobRepository.save(job);
        return convertToDTO(savedJob);
    }

    /**
     * Get job by ID
     */
    @Transactional(readOnly = true)
    public JobDTO getJobById(Long jobId) {
        Job job = jobRepository.findById(jobId)
                .orElseThrow(() -> new RuntimeException("Job not found"));
        return convertToDTO(job);
    }

    /**
     * Get jobs by user
     */
    @Transactional(readOnly = true)
    public Page<JobDTO> getJobsByUser(Long userId, Pageable pageable) {
        return jobRepository.findByUserId(userId, pageable)
                .map(this::convertToDTO);
    }

    /**
     * Get open jobs
     */
    @Transactional(readOnly = true)
    public Page<JobDTO> getOpenJobs(Pageable pageable) {
        return jobRepository.findByStatus(JobStatus.OPEN, pageable)
                .map(this::convertToDTO);
    }

    /**
     * Search jobs
     */
    @Transactional(readOnly = true)
    public Page<JobDTO> searchJobs(String keyword, Pageable pageable) {
        return jobRepository.searchJobs(keyword, JobStatus.OPEN, pageable)
                .map(this::convertToDTO);
    }

    /**
     * Update job status
     */
    public JobDTO updateJobStatus(Long jobId, JobStatus status, Long userId) {
        Job job = jobRepository.findById(jobId)
                .orElseThrow(() -> new RuntimeException("Job not found"));

        if (!job.getUser().getId().equals(userId)) {
            throw new RuntimeException("Unauthorized to update this job");
        }

        job.setStatus(status);
        Job savedJob = jobRepository.save(job);
        return convertToDTO(savedJob);
    }

    /**
     * Delete job
     */
    public void deleteJob(Long jobId, Long userId) {
        Job job = jobRepository.findById(jobId)
                .orElseThrow(() -> new RuntimeException("Job not found"));

        if (!job.getUser().getId().equals(userId)) {
            throw new RuntimeException("Unauthorized to delete this job");
        }

        jobRepository.delete(job);
    }

    /**
     * Convert Job entity to JobDTO
     */
    private JobDTO convertToDTO(Job job) {
        return JobDTO.builder()
                .id(job.getId())
                .userId(job.getUser().getId())
                .userName(job.getUser().getName())
                .title(job.getTitle())
                .description(job.getDescription())
                .category(job.getCategory())
                .location(job.getLocation())
                .budgetMin(job.getBudgetMin())
                .budgetMax(job.getBudgetMax())
                .jobType(job.getJobType())
                .durationHours(job.getDurationHours())
                .urgency(job.getUrgency())
                .status(job.getStatus())
                .requiredSkills(job.getRequiredSkills())
                .preferredExperience(job.getPreferredExperience())
                .attachments(job.getAttachments())
                .createdAt(job.getCreatedAt())
                .updatedAt(job.getUpdatedAt())
                .applicationCount(job.getApplications() != null ? job.getApplications().size() : 0)
                .build();
    }
}