package com.project.upwork.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Professional DTO - Response DTO for professional profile
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProfessionalDTO {
    private Long id;
    private String name;
    private String email;
    private String bio;
    private BigDecimal hourlyRate;
    private String location;
    private BigDecimal totalRating;  // Average rating
    private Integer ratingCount;      // Number of reviews
    private String verificationStatus;
    private Integer yearsOfExperience;
    private BigDecimal totalEarnings;
    private String profilePictureUrl;
    private LocalDateTime createdAt;
}
