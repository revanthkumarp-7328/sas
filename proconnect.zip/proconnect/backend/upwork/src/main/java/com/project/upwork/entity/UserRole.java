package com.project.upwork.entity;

/**
 * User Role Enumeration
 * Defines the different roles in the system
 */
public enum UserRole {
    USER,           // Regular customer
    PROFESSIONAL,   // Service provider
    ADMIN,          // Administrator
    SUPPORT         // Customer support staff
}
