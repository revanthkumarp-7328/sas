package com.project.upwork.service;

import com.project.upwork.dto.ProfessionalDTO;
import com.project.upwork.dto.JobDTO;
import com.project.upwork.dto.UserDTO;
import com.project.upwork.entity.*;
import com.project.upwork.exception.ResourceNotFoundException;
import com.project.upwork.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Admin Service
 * Handles admin operations like approvals, suspensions, and analytics
 */
@org.springframework.stereotype.Service
@Transactional
public class AdminService {
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private ProfessionalRepository professionalRepository;
    
    @Autowired
    private JobRepository jobRepository;
    
    @Autowired
    private ApplicationRepository applicationRepository;
    
    @Autowired
    private SupportTicketRepository supportTicketRepository;
    
    /**
     * Get paginated list of all users
     */
    public Page<UserDTO> getAllUsers(Pageable pageable) {
        return userRepository.findAll(pageable)
                .map(this::convertUserToDTO);
    }
    
    /**
     * Get all pending professional verification requests
     */
    public List<ProfessionalDTO> getPendingVerifications() {
        return professionalRepository.findByVerificationStatus(VerificationStatus.PENDING)
                .stream()
                .map(this::convertProfessionalToDTO)
                .collect(Collectors.toList());
    }
    
    /**
     * Approve professional verification
     */
    public ProfessionalDTO approveProfessional(Long professionalId) {
        Professional professional = professionalRepository.findById(professionalId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Professional", "id", professionalId)
                );
        
        professional.setVerificationStatus(VerificationStatus.VERIFIED);
        professional = professionalRepository.save(professional);
        
        return convertProfessionalToDTO(professional);
    }
    
    /**
     * Reject professional verification
     */
    public ProfessionalDTO rejectProfessional(Long professionalId) {
        Professional professional = professionalRepository.findById(professionalId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Professional", "id", professionalId)
                );
        
        professional.setVerificationStatus(VerificationStatus.REJECTED);
        professional = professionalRepository.save(professional);
        
        return convertProfessionalToDTO(professional);
    }
    
    /**
     * Suspend user account
     */
    public UserDTO suspendUser(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("User", "id", userId)
                );
        
        user.setIsActive(false);
        user = userRepository.save(user);
        
        return convertUserToDTO(user);
    }
    
    /**
     * Activate user account
     */
    public UserDTO activateUser(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("User", "id", userId)
                );
        
        user.setIsActive(true);
        user = userRepository.save(user);
        
        return convertUserToDTO(user);
    }
    
    /**
     * Deactivate job posting
     */
    public JobDTO deactivateJob(Long jobId) {
        Job job = jobRepository.findById(jobId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Job", "id", jobId)
                );
        
        job.setStatus(JobStatus.CANCELLED);
        job = jobRepository.save(job);
        
        return convertJobToDTO(job);
    }
    
    /**
     * Get dashboard analytics
     */
    public AdminDashboardAnalytics getDashboardAnalytics() {
        long totalUsers = userRepository.count();
        long totalProfessionals = professionalRepository.count();
        long totalJobs = jobRepository.count();
        long openJobs = jobRepository.countByStatus(JobStatus.OPEN);
        long totalApplications = applicationRepository.count();
        long acceptedApplications = applicationRepository.countByStatus(ApplicationStatus.ACCEPTED);
        long pendingVerifications = professionalRepository.findByVerificationStatus(VerificationStatus.PENDING)
                .size();
        long openSupportTickets = supportTicketRepository.findByStatus(SupportTicketStatus.OPEN,
                org.springframework.data.domain.PageRequest.of(0, Integer.MAX_VALUE))
                .getTotalElements();

        return AdminDashboardAnalytics.builder()
                .totalUsers(totalUsers)
                .totalProfessionals(totalProfessionals)
                .totalJobs(totalJobs)
                .openJobs(openJobs)
                .totalApplications(totalApplications)
                .acceptedApplications(acceptedApplications)
                .pendingVerifications(pendingVerifications)
                .openSupportTickets(openSupportTickets)
                .build();
    }
    
    /**
     * Get all applications (paginated)
     */
    public Page<Object> getAllApplications(Pageable pageable) {
        return applicationRepository.findAll(pageable)
                .map(Object.class::cast);
    }
    
    /**
     * Get all support tickets (paginated)
     */
    public Page<Object> getAllSupportTickets(Pageable pageable) {
        return supportTicketRepository.findAll(pageable)
                .map(Object.class::cast);
    }
    
    /**
     * Helper method to convert User to UserDTO
     */
    private UserDTO convertUserToDTO(User user) {
        return UserDTO.builder()
                .id(user.getId())
                .email(user.getEmail())
                .name(user.getName())
                .phone(user.getPhone())
                .role(user.getRole().toString())
                .isActive(user.getIsActive())
                .createdAt(user.getCreatedAt())
                .updatedAt(user.getUpdatedAt())
                .build();
    }
    
    /**
     * Helper method to convert Professional to ProfessionalDTO
     */
    private ProfessionalDTO convertProfessionalToDTO(Professional professional) {
        return ProfessionalDTO.builder()
                .id(professional.getId())
                .name(professional.getUser().getName())
                .bio(professional.getBio())
                .hourlyRate(professional.getHourlyRate())
                .location(professional.getLocation())
                .totalRating(professional.getTotalRating())
                .ratingCount(professional.getRatingCount())
                .verificationStatus(professional.getVerificationStatus().toString())
                .totalEarnings(professional.getTotalEarnings())
                .build();
    }
    
    /**
     * Helper method to convert Service to ServiceDTO
     */
    private JobDTO convertJobToDTO(Job job) {
        JobDTO.JobDTOBuilder builder = JobDTO.builder()
                .id(job.getId())
                .title(job.getTitle())
                .description(job.getDescription())
                .budgetMin(job.getBudgetMin())
                .budgetMax(job.getBudgetMax())
                .location(job.getLocation())
                .category(job.getCategory())
                .requiredSkills(job.getRequiredSkills())
                .preferredExperience(job.getPreferredExperience())
                .attachments(job.getAttachments())
                .jobType(job.getJobType())
                .urgency(job.getUrgency())
                .status(job.getStatus())
                .userId(job.getUser().getId())
                .userName(job.getUser().getName())
                .createdAt(job.getCreatedAt())
                .updatedAt(job.getUpdatedAt());

        long applicationCount = applicationRepository.countByJobId(job.getId());
        builder.applicationCount((int) applicationCount);

        return builder.build();
    }
}

/**
 * DTO for admin dashboard analytics
 */
class AdminDashboardAnalytics {
    private Long totalUsers;
    private Long totalProfessionals;
    private Long totalBookings;
    private Long completedBookings;
    private Long pendingVerifications;
    private Long openSupportTickets;
    private Long totalJobs;
    private Long openJobs;
    private Long totalApplications;
    private Long acceptedApplications;
    
    // Builder pattern
    public static AdminDashboardAnalyticsBuilder builder() {
        return new AdminDashboardAnalyticsBuilder();
    }
    
    public static class AdminDashboardAnalyticsBuilder {
        private Long totalUsers;
        private Long totalProfessionals;
        private Long totalJobs;
        private Long openJobs;
        private Long totalApplications;
        private Long acceptedApplications;
        private Long pendingVerifications;
        private Long openSupportTickets;
        
        public AdminDashboardAnalyticsBuilder totalUsers(Long totalUsers) {
            this.totalUsers = totalUsers;
            return this;
        }
        
        public AdminDashboardAnalyticsBuilder totalProfessionals(Long totalProfessionals) {
            this.totalProfessionals = totalProfessionals;
            return this;
        }
        
        public AdminDashboardAnalyticsBuilder totalJobs(Long totalJobs) {
            this.totalJobs = totalJobs;
            return this;
        }
        
        public AdminDashboardAnalyticsBuilder openJobs(Long openJobs) {
            this.openJobs = openJobs;
            return this;
        }
        
        public AdminDashboardAnalyticsBuilder totalApplications(Long totalApplications) {
            this.totalApplications = totalApplications;
            return this;
        }
        
        public AdminDashboardAnalyticsBuilder acceptedApplications(Long acceptedApplications) {
            this.acceptedApplications = acceptedApplications;
            return this;
        }
        
        public AdminDashboardAnalyticsBuilder pendingVerifications(Long pendingVerifications) {
            this.pendingVerifications = pendingVerifications;
            return this;
        }
        
        public AdminDashboardAnalyticsBuilder openSupportTickets(Long openSupportTickets) {
            this.openSupportTickets = openSupportTickets;
            return this;
        }
        
        public AdminDashboardAnalytics build() {
            AdminDashboardAnalytics analytics = new AdminDashboardAnalytics();
            analytics.totalUsers = this.totalUsers;
            analytics.totalProfessionals = this.totalProfessionals;
            analytics.totalJobs = this.totalJobs;
            analytics.openJobs = this.openJobs;
            analytics.totalApplications = this.totalApplications;
            analytics.acceptedApplications = this.acceptedApplications;
            analytics.pendingVerifications = this.pendingVerifications;
            analytics.openSupportTickets = this.openSupportTickets;
            return analytics;
        }
    }
    
    public Long getTotalUsers() { return totalUsers; }
    public Long getTotalProfessionals() { return totalProfessionals; }
    public Long getTotalJobs() { return totalJobs; }
    public Long getOpenJobs() { return openJobs; }
    public Long getTotalApplications() { return totalApplications; }
    public Long getAcceptedApplications() { return acceptedApplications; }
    public Long getPendingVerifications() { return pendingVerifications; }
    public Long getOpenSupportTickets() { return openSupportTickets; }
}
