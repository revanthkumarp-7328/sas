package com.project.upwork.entity;

/**
 * Support Ticket Status Enumeration
 */
public enum SupportTicketStatus {
    OPEN,           // Newly created ticket
    IN_PROGRESS,    // Being worked on by support staff
    RESOLVED,       // Issue has been resolved
    CLOSED          // Ticket is closed
}
