package com.project.upwork.repository;

import com.project.upwork.entity.Application;
import com.project.upwork.entity.ApplicationStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Application Repository - Data access layer for Application entities
 */
@Repository
public interface ApplicationRepository extends JpaRepository<Application, Long> {

    // Find applications by job
    Page<Application> findByJobId(Long jobId, Pageable pageable);

    // Find applications by professional
    Page<Application> findByProfessionalId(Long professionalId, Pageable pageable);

    // Find applications by status
    Page<Application> findByStatus(ApplicationStatus status, Pageable pageable);

    // Find applications by job and status
    Page<Application> findByJobIdAndStatus(Long jobId, ApplicationStatus status, Pageable pageable);

    // Find applications by professional and status
    Page<Application> findByProfessionalIdAndStatus(Long professionalId, ApplicationStatus status, Pageable pageable);

    // Check if professional has already applied to job
    boolean existsByJobIdAndProfessionalId(Long jobId, Long professionalId);

    // Find application by job and professional
    Optional<Application> findByJobIdAndProfessionalId(Long jobId, Long professionalId);

    // Count applications by job
    long countByJobId(Long jobId);

    // Count applications by professional
    long countByProfessionalId(Long professionalId);

    // Count applications by status
    long countByStatus(ApplicationStatus status);

    // Find applications by job with professional details
    @Query("SELECT a FROM Application a JOIN FETCH a.professional WHERE a.job.id = :jobId")
    List<Application> findByJobIdWithProfessional(@Param("jobId") Long jobId);

    // Find applications by professional with job details
    @Query("SELECT a FROM Application a JOIN FETCH a.job WHERE a.professional.id = :professionalId")
    List<Application> findByProfessionalIdWithJob(@Param("professionalId") Long professionalId);
}