package com.project.upwork.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Application Entity - Professional applications for jobs
 */
@Entity
@Table(name = "applications", indexes = {
    @Index(name = "idx_job_id", columnList = "job_id"),
    @Index(name = "idx_professional_id", columnList = "professional_id"),
    @Index(name = "idx_status", columnList = "status"),
    @Index(name = "idx_applied_at", columnList = "applied_at")
}, uniqueConstraints = {
    @UniqueConstraint(name = "unique_job_professional", columnNames = {"job_id", "professional_id"})
})
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Application {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "job_id", nullable = false)
    @JsonIgnore
    private Job job;

    @ManyToOne
    @JoinColumn(name = "professional_id", nullable = false)
    @JsonIgnore
    private Professional professional;

    @Column(precision = 10, scale = 2)
    private BigDecimal proposedPrice;

    @Column
    private Integer proposedDuration;

    @Column(columnDefinition = "TEXT")
    private String coverLetter;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    @Builder.Default
    private ApplicationStatus status = ApplicationStatus.PENDING;

    @Column(nullable = false, updatable = false)
    @Builder.Default
    private LocalDateTime appliedAt = LocalDateTime.now();

    @Column(nullable = false)
    @Builder.Default
    private LocalDateTime updatedAt = LocalDateTime.now();

    // Relationships
    @OneToOne(mappedBy = "application", cascade = CascadeType.ALL, orphanRemoval = true)
    private Review review;

    @PrePersist
    protected void onCreate() {
        appliedAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}