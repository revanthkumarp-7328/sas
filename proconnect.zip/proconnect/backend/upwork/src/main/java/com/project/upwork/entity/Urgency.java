package com.project.upwork.entity;

/**
 * Job Urgency Enumeration
 * Represents the urgency level of a job posting
 */
public enum Urgency {
    LOW,     // Not urgent, flexible timeline
    MEDIUM,  // Moderate urgency
    HIGH     // Urgent, needs immediate attention
}