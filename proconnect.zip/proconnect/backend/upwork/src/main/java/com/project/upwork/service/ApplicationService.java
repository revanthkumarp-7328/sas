package com.project.upwork.service;

import com.project.upwork.dto.ApplicationDTO;
import com.project.upwork.dto.CreateApplicationRequestDTO;
import com.project.upwork.entity.*;
import com.project.upwork.repository.ApplicationRepository;
import com.project.upwork.repository.JobRepository;
import com.project.upwork.repository.ProfessionalRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Application Service - Business logic for job applications
 */
@Service
@RequiredArgsConstructor
@Transactional
public class ApplicationService {

    private final ApplicationRepository applicationRepository;
    private final JobRepository jobRepository;
    private final ProfessionalRepository professionalRepository;

    /**
     * Create a new application
     */
    public ApplicationDTO createApplication(CreateApplicationRequestDTO request, Long professionalId) {
        Job job = jobRepository.findById(request.getJobId())
                .orElseThrow(() -> new RuntimeException("Job not found"));

        Professional professional = professionalRepository.findById(professionalId)
                .orElseThrow(() -> new RuntimeException("Professional not found"));

        // Check if professional already applied
        if (applicationRepository.existsByJobIdAndProfessionalId(request.getJobId(), professionalId)) {
            throw new RuntimeException("You have already applied to this job");
        }

        // Check if job is still open
        if (job.getStatus() != JobStatus.OPEN) {
            throw new RuntimeException("This job is no longer accepting applications");
        }

        Application application = Application.builder()
                .job(job)
                .professional(professional)
                .proposedPrice(request.getProposedPrice())
                .proposedDuration(request.getProposedDuration())
                .coverLetter(request.getCoverLetter())
                .status(ApplicationStatus.PENDING)
                .build();

        Application savedApplication = applicationRepository.save(application);
        return convertToDTO(savedApplication);
    }

    /**
     * Get application by ID
     */
    @Transactional(readOnly = true)
    public ApplicationDTO getApplicationById(Long applicationId) {
        Application application = applicationRepository.findById(applicationId)
                .orElseThrow(() -> new RuntimeException("Application not found"));
        return convertToDTO(application);
    }

    /**
     * Get applications for a job
     */
    @Transactional(readOnly = true)
    public Page<ApplicationDTO> getApplicationsByJob(Long jobId, Long userId, Pageable pageable) {
        Job job = jobRepository.findById(jobId)
                .orElseThrow(() -> new RuntimeException("Job not found"));

        // Check if user owns the job
        if (!job.getUser().getId().equals(userId)) {
            throw new RuntimeException("Unauthorized to view applications for this job");
        }

        return applicationRepository.findByJobId(jobId, pageable)
                .map(this::convertToDTO);
    }

    /**
     * Get applications by professional
     */
    @Transactional(readOnly = true)
    public Page<ApplicationDTO> getApplicationsByProfessional(Long professionalId, Pageable pageable) {
        return applicationRepository.findByProfessionalId(professionalId, pageable)
                .map(this::convertToDTO);
    }

    /**
     * Update application status
     */
    public ApplicationDTO updateApplicationStatus(Long applicationId, ApplicationStatus status, Long userId) {
        Application application = applicationRepository.findById(applicationId)
                .orElseThrow(() -> new RuntimeException("Application not found"));

        // Check if user owns the job
        if (!application.getJob().getUser().getId().equals(userId)) {
            throw new RuntimeException("Unauthorized to update this application");
        }

        application.setStatus(status);
        Application savedApplication = applicationRepository.save(application);
        return convertToDTO(savedApplication);
    }

    /**
     * Withdraw application
     */
    public void withdrawApplication(Long applicationId, Long professionalId) {
        Application application = applicationRepository.findById(applicationId)
                .orElseThrow(() -> new RuntimeException("Application not found"));

        // Check if professional owns the application
        if (!application.getProfessional().getId().equals(professionalId)) {
            throw new RuntimeException("Unauthorized to withdraw this application");
        }

        // Check if application can be withdrawn
        if (application.getStatus() != ApplicationStatus.PENDING) {
            throw new RuntimeException("Cannot withdraw application that is not pending");
        }

        applicationRepository.delete(application);
    }

    /**
     * Convert Application entity to ApplicationDTO
     */
    private ApplicationDTO convertToDTO(Application application) {
        return ApplicationDTO.builder()
                .id(application.getId())
                .jobId(application.getJob().getId())
                .jobTitle(application.getJob().getTitle())
                .professionalId(application.getProfessional().getId())
                .professionalName(application.getProfessional().getUser().getName())
                .proposedPrice(application.getProposedPrice())
                .proposedDuration(application.getProposedDuration())
                .coverLetter(application.getCoverLetter())
                .status(application.getStatus())
                .appliedAt(application.getAppliedAt())
                .updatedAt(application.getUpdatedAt())
                .build();
    }
}