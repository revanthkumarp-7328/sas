package com.project.upwork.exception;

/**
 * Invalid Booking Exception
 * Thrown when booking operation is invalid
 */
public class InvalidBookingException extends RuntimeException {
    public InvalidBookingException(String message) {
        super(message);
    }
}
