package com.project.upwork.entity;

/**
 * Job Type Enumeration
 * Represents whether a job is fixed-price or hourly
 */
public enum JobType {
    FIXED,   // Fixed-price job
    HOURLY   // Hourly rate job
}