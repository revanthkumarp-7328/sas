import { Link } from "react-router-dom";

const Navbar = ({ user, onLogout }) => {
  return (
    <header className="navbar">
      <div className="navbar-brand">
        <Link to="/">upWork</Link>
      </div>
      <nav className="navbar-links">
        <Link to="/jobs">Jobs</Link>
        <Link to="/professionals">Professionals</Link>
        <Link to="/applications">Applications</Link>
        <Link to="/support">Support</Link>
        {user ? <Link to="/profile">Profile</Link> : null}
      </nav>
      <div className="navbar-actions">
        {user ? (
          <>
            <span className="navbar-user">{user.username || user.email}</span>
            <button type="button" className="btn btn-ghost" onClick={onLogout}>
              Logout
            </button>
          </>
        ) : (
          <>
            <Link to="/login" className="btn btn-primary">
              Login
            </Link>
            <Link to="/register" className="btn btn-secondary">
              Register
            </Link>
          </>
        )}
      </div>
    </header>
  );
};

export default Navbar;
