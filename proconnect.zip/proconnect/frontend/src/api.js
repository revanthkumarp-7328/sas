import axios from "axios";

const apiClient = axios.create({
  baseURL: "/api",
  headers: {
    "Content-Type": "application/json",
  },
});

const normalizeResponse = (response) => response?.data ?? null;

const setToken = (token) => {
  if (token) {
    apiClient.defaults.headers.common.Authorization = `Bearer ${token}`;
  } else {
    delete apiClient.defaults.headers.common.Authorization;
  }
};

const getPageContent = (payload) => {
  if (payload && Array.isArray(payload.content)) {
    return payload.content;
  }
  return payload;
};

export default {
  setToken,
  register: (payload) =>
    normalizeResponse(apiClient.post("/auth/register", payload)),
  login: async (payload) =>
    normalizeResponse(await apiClient.post("/auth/login", payload)),
  fetchCurrentUser: async () =>
    normalizeResponse(await apiClient.get("/auth/me")),
  getTopProfessionals: async () =>
    getPageContent(
      normalizeResponse(await apiClient.get("/professionals/top")),
    ),
  getProfessionals: async () =>
    getPageContent(normalizeResponse(await apiClient.get("/professionals"))),
  getOpenJobs: async (page = 0, size = 10) =>
    getPageContent(
      normalizeResponse(
        await apiClient.get(`/jobs/open?page=${page}&size=${size}`),
      ),
    ),
  getMyJobs: async (page = 0, size = 10) =>
    getPageContent(
      normalizeResponse(
        await apiClient.get(`/jobs/my-jobs?page=${page}&size=${size}`),
      ),
    ),
  createJob: async (payload) =>
    normalizeResponse(await apiClient.post("/jobs", payload)),
  searchJobs: async (keyword, page = 0, size = 10) =>
    getPageContent(
      normalizeResponse(
        await apiClient.get(
          `/jobs/search?keyword=${encodeURIComponent(keyword)}&page=${page}&size=${size}`,
        ),
      ),
    ),
  getJobById: async (jobId) =>
    normalizeResponse(await apiClient.get(`/jobs/${jobId}`)),
  createApplication: async (payload) =>
    normalizeResponse(await apiClient.post("/applications", payload)),
  getMyApplications: async (page = 0, size = 10) =>
    getPageContent(
      normalizeResponse(
        await apiClient.get(
          `/applications/my-applications?page=${page}&size=${size}`,
        ),
      ),
    ),
  getApplicationsByJob: async (jobId, page = 0, size = 10) =>
    getPageContent(
      normalizeResponse(
        await apiClient.get(
          `/applications/job/${jobId}?page=${page}&size=${size}`,
        ),
      ),
    ),
  withdrawApplication: async (applicationId) =>
    normalizeResponse(await apiClient.delete(`/applications/${applicationId}`)),
  createSupportTicket: async (payload) =>
    normalizeResponse(await apiClient.post("/support", payload)),
  getUserSupportTickets: async (userId) =>
    getPageContent(
      normalizeResponse(await apiClient.get(`/support/user/${userId}`)),
    ),
  createReview: async (payload) =>
    normalizeResponse(await apiClient.post("/reviews", payload)),
};
