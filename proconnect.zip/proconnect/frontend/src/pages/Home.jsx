import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "../api";

const Home = ({ user }) => {
  const [professionals, setProfessionals] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    api
      .getTopProfessionals()
      .then(setProfessionals)
      .catch((err) =>
        setError(
          err.response?.data || err.message || "Failed to load professionals",
        ),
      );

    api
      .getOpenJobs()
      .then(setJobs)
      .catch((err) =>
        setError(err.response?.data || err.message || "Failed to load jobs"),
      );
  }, []);

  return (
    <div className="page-content">
      <section className="intro-text">
        <p>
          upWork helps customers post jobs, hire verified professionals, and
          manage applications from one modern job portal. Create your account,
          browse opportunities, and connect with trusted experts.
        </p>
      </section>

      <section className="hero-card">
        <div>
          <h1>Find jobs or hire top talent faster</h1>
          <p>
            Browse open jobs, compare verified professionals, and manage
            applications with a modern job portal experience.
          </p>
          <div className="hero-actions">
            {user ? (
              <Link to="/jobs" className="btn btn-primary">
                Browse Jobs
              </Link>
            ) : (
              <>
                <Link to="/register" className="btn btn-primary">
                  Get Started
                </Link>
                <Link to="/login" className="btn btn-secondary">
                  Sign In
                </Link>
              </>
            )}
          </div>
        </div>
      </section>

      <section className="section-block">
        <h2>Top Professionals</h2>
        <p className="intro-text">
          Learn more about the professionals available for your jobs and hiring
          needs. Each profile highlights a verified expert, their experience,
          and current rating.
        </p>
        {error && <p className="error-message">{error}</p>}
        <div className="grid-list">
          {professionals.length > 0 ? (
            professionals.slice(0, 4).map((pro) => (
              <article key={pro.id} className="card">
                <h3>{pro.name || "Professional"}</h3>
                <p>{pro.bio || "Trusted local specialist"}</p>
                <p>{pro.location || "Location not listed"}</p>
                <p>
                  Rating:{" "}
                  {pro.totalRating?.toFixed?.(1) ?? pro.totalRating ?? "N/A"} (
                  {pro.ratingCount ?? 0} reviews)
                </p>
                <p>
                  Hourly rate:{" "}
                  {pro.hourlyRate ? `$${pro.hourlyRate}` : "Varies"}
                </p>
              </article>
            ))
          ) : (
            <p>No top professionals available yet.</p>
          )}
        </div>
      </section>

      <section className="section-block">
        <h2>Open Jobs</h2>
        <p className="intro-text">
          Explore the latest job opportunities with clear scope, budget, and
          location details.
        </p>
        <div className="grid-list">
          {jobs.length > 0 ? (
            jobs.slice(0, 4).map((job) => (
              <article key={job.id} className="card">
                <h3>{job.title || `Job ${job.id}`}</h3>
                <p>
                  {job.description || "A rewarding project with a clear scope."}
                </p>
                <p>
                  <strong>Category:</strong> {job.category || "General"}
                </p>
                <p>
                  <strong>Budget:</strong>{" "}
                  {job.budgetMin ? `$${job.budgetMin}` : "N/A"} -{" "}
                  {job.budgetMax ? `$${job.budgetMax}` : "N/A"}
                </p>
                <p>
                  <strong>Location:</strong> {job.location || "Remote"}
                </p>
              </article>
            ))
          ) : (
            <p>No open jobs available yet.</p>
          )}
        </div>
      </section>
    </div>
  );
};

export default Home;
