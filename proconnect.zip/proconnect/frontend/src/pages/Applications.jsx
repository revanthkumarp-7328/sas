import { useEffect, useState } from "react";
import api from "../api";

const Applications = ({ user }) => {
  const [applications, setApplications] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [jobId, setJobId] = useState("");
  const [proposal, setProposal] = useState("");
  const [message, setMessage] = useState(null);
  const [error, setError] = useState(null);

  const loadApplications = async () => {
    if (!user?.id) {
      return;
    }

    try {
      const response = await api.getMyApplications();
      setApplications(response);
    } catch (err) {
      setError(
        err.response?.data || err.message || "Unable to load applications",
      );
    }
  };

  useEffect(() => {
    if (!user?.id) {
      return;
    }

    api
      .getOpenJobs()
      .then(setJobs)
      .catch(() => {});

    loadApplications();
  }, [user]);

  const handleWithdraw = async (applicationId) => {
    if (!confirm("Are you sure you want to withdraw this application?")) {
      return;
    }

    try {
      await api.withdrawApplication(applicationId);
      setMessage("Application withdrawn successfully.");
      setApplications((current) =>
        current.filter((app) => app.id !== applicationId),
      );
    } catch (err) {
      setError(
        err.response?.data || err.message || "Failed to withdraw application",
      );
    }
  };

  return (
    <section className="page-content">
      <h2>Applications</h2>
      {user ? (
        <>
          <div className="card form-panel">
            <h3>Submit an application</h3>
            <form onSubmit={handleSubmit} className="form-grid">
              <label>
                Job
                <select
                  value={jobId}
                  onChange={(event) => setJobId(event.target.value)}
                  required
                >
                  <option value="">Select a job</option>
                  {jobs.map((job) => (
                    <option key={job.id} value={job.id}>
                      {job.title || `Job ${job.id}`} -{" "}
                      {job.location || "Remote"}
                    </option>
                  ))}
                </select>
              </label>
              <label>
                Proposal
                <textarea
                  value={proposal}
                  onChange={(event) => setProposal(event.target.value)}
                  rows="4"
                  placeholder="Why are you a good fit for this role?"
                  required
                />
              </label>
              {message && <p className="success-message">{message}</p>}
              {error && <p className="error-message">{error}</p>}
              <button className="btn btn-primary" type="submit">
                Submit Application
              </button>
            </form>
          </div>

          <div className="section-block">
            <h3>My applications</h3>
            {applications.length > 0 ? (
              applications.map((application) => (
                <article key={application.id} className="card">
                  <p>
                    <strong>Application ID:</strong> {application.id}
                  </p>
                  <p>
                    <strong>Job:</strong> {application.jobTitle || "Unknown"}
                  </p>
                  <p>
                    <strong>Status:</strong> {application.status || "Submitted"}
                  </p>
                  {application.proposal && (
                    <p>
                      <strong>Proposal:</strong> {application.proposal}
                    </p>
                  )}
                  <button
                    className="btn btn-danger"
                    onClick={() => handleWithdraw(application.id)}
                  >
                    Withdraw Application
                  </button>
                </article>
              ))
            ) : (
              <p>No applications found.</p>
            )}
          </div>
        </>
      ) : (
        <p>Please sign in to view and manage your applications.</p>
      )}
    </section>
  );
};

export default Applications;
