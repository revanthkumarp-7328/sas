import { useEffect, useState } from "react";
import api from "../api";

const Support = ({ user }) => {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("General");
  const [priority, setPriority] = useState("MEDIUM");
  const [tickets, setTickets] = useState([]);
  const [message, setMessage] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!user?.id) {
      return;
    }

    api
      .getUserSupportTickets(user.id)
      .then(setTickets)
      .catch((err) =>
        setError(err.message || "Unable to load support tickets"),
      );
  }, [user]);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError(null);
    setMessage(null);

    if (!user?.id) {
      setError("Please sign in to submit a support request.");
      return;
    }

    // Convert priority string to integer (1=HIGH, 2=MEDIUM, 3=LOW)
    const priorityMap = { HIGH: 1, MEDIUM: 2, LOW: 3 };
    const priorityValue = priorityMap[priority] || 2;

    try {
      await api.createSupportTicket({
        userId: user.id,
        title,
        description,
        category,
        priority: priorityValue,
      });
      setMessage("Support request submitted successfully.");
      setTitle("");
      setDescription("");
      setCategory("General");
      setPriority("MEDIUM");

      // Reload tickets with error handling
      try {
        const updatedTickets = await api.getUserSupportTickets(user.id);
        setTickets(updatedTickets);
      } catch (ticketErr) {
        console.error("Failed to reload tickets:", ticketErr);
        // Don't show error for ticket reload failure, just log it
      }
    } catch (err) {
      setError(err.response?.data || err.message || "Failed to submit request");
    }
  };

  return (
    <section className="page-content">
      <div className="intro-text">
        <h2>Support Center</h2>
        <p>
          Submit requests for booking help, service questions, account problems,
          or urgent issues. Track ticket status and stay informed until your
          issue is resolved.
        </p>
      </div>
      {user ? (
        <>
          <div className="card form-panel">
            <h3>Submit a request</h3>
            <form onSubmit={handleSubmit} className="form-grid">
              <label>
                Title
                <input
                  value={title}
                  onChange={(event) => setTitle(event.target.value)}
                  type="text"
                  required
                />
              </label>
              <label>
                Description
                <textarea
                  value={description}
                  onChange={(event) => setDescription(event.target.value)}
                  rows="4"
                  required
                />
              </label>
              <label>
                Category
                <select
                  value={category}
                  onChange={(event) => setCategory(event.target.value)}
                >
                  <option>General</option>
                  <option>Billing</option>
                  <option>Technical</option>
                  <option>Service</option>
                </select>
              </label>
              <label>
                Priority
                <select
                  value={priority}
                  onChange={(event) => setPriority(event.target.value)}
                >
                  <option value="LOW">Low</option>
                  <option value="MEDIUM">Medium</option>
                  <option value="HIGH">High</option>
                </select>
              </label>
              {message && <p className="success-message">{message}</p>}
              {error && <p className="error-message">{error}</p>}
              <button className="btn btn-primary" type="submit">
                Submit Ticket
              </button>
            </form>
          </div>

          <div className="section-block">
            <h3>My tickets</h3>
            {tickets.length > 0 ? (
              tickets.map((ticket) => (
                <article key={ticket.id} className="card">
                  <h3>{ticket.title}</h3>
                  <p>{ticket.description}</p>
                  <p>
                    <strong>Category:</strong> {ticket.category || "General"}
                  </p>
                  <p>
                    <strong>Status:</strong> {ticket.status || "New"}
                  </p>
                </article>
              ))
            ) : (
              <p>No support tickets found.</p>
            )}
          </div>
        </>
      ) : (
        <p>Please sign in to submit support requests and view tickets.</p>
      )}
    </section>
  );
};

export default Support;
