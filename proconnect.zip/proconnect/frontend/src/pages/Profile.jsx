const Profile = ({ user }) => {
  if (!user) {
    return (
      <section className="page-content">
        <h2>Profile</h2>
        <p>Please sign in to view your profile information.</p>
      </section>
    );
  }

  return (
    <section className="page-content profile-panel">
      <h2>My Profile</h2>
      <div className="card profile-card">
        <div>
          <strong>Name</strong>
          <p>{user.username || user.name || "—"}</p>
        </div>
        <div>
          <strong>Email</strong>
          <p>{user.email}</p>
        </div>
        {user.role && (
          <div>
            <strong>Role</strong>
            <p>{user.role}</p>
          </div>
        )}
        {user.phone && (
          <div>
            <strong>Phone</strong>
            <p>{user.phone}</p>
          </div>
        )}
        {user.location && (
          <div>
            <strong>Location</strong>
            <p>{user.location}</p>
          </div>
        )}
      </div>
    </section>
  );
};

export default Profile;
