import { useEffect, useState } from "react";
import api from "../api";

const Jobs = () => {
  const [jobs, setJobs] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    api
      .getOpenJobs()
      .then(setJobs)
      .catch((err) =>
        setError(err.response?.data || err.message || "Failed to load jobs"),
      );
  }, []);

  return (
    <section className="page-content">
      <div className="intro-text">
        <h2>Open Jobs</h2>
        <p>
          Discover current job opportunities and apply to projects that match
          your skills, availability, and goals.
        </p>
      </div>
      {error && <p className="error-message">{error}</p>}
      <div className="grid-list">
        {jobs.length > 0 ? (
          jobs.map((job) => (
            <article key={job.id} className="card">
              <h3>{job.title || `Job ${job.id}`}</h3>
              <p>
                {job.description || "A great opportunity with a clear scope."}
              </p>
              <p>
                <strong>Category:</strong> {job.category || "General"}
              </p>
              <p>
                <strong>Budget:</strong>{" "}
                {job.budgetMin ? `$${job.budgetMin}` : "N/A"} -{" "}
                {job.budgetMax ? `$${job.budgetMax}` : "N/A"}
              </p>
              <p>
                <strong>Location:</strong> {job.location || "Remote"}
              </p>
              <p>
                <strong>Status:</strong> {job.status || "Open"}
              </p>
            </article>
          ))
        ) : (
          <p>No jobs are available right now.</p>
        )}
      </div>
    </section>
  );
};

export default Jobs;
