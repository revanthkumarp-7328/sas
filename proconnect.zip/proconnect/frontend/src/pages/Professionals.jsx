import { useEffect, useState } from "react";
import api from "../api";

const Professionals = () => {
  const [professionals, setProfessionals] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    api
      .getProfessionals()
      .then(setProfessionals)
      .catch((err) =>
        setError(
          err.response?.data || err.message || "Failed to load professionals",
        ),
      );
  }, []);

  return (
    <section className="page-content">
      <div className="intro-text">
        <h2>Verified Professionals</h2>
        <p>
          Explore trusted experts for your next project. Browse by ratings,
          hourly rate, and location to hire the professional who best fits your
          needs.
        </p>
      </div>
      {error && <p className="error-message">{error}</p>}
      <div className="grid-list">
        {professionals.length > 0 ? (
          professionals.map((pro) => (
            <article key={pro.id} className="card">
              <h3>{pro.name || "Verified Professional"}</h3>
              <p>{pro.bio || "Experienced expert available for hire."}</p>
              <p>{pro.location || "Location not listed"}</p>
              <p>
                Rating:{" "}
                {pro.totalRating?.toFixed?.(1) ?? pro.totalRating ?? "N/A"} (
                {pro.ratingCount ?? 0} reviews)
              </p>
              <p>
                Hourly rate: {pro.hourlyRate ? `$${pro.hourlyRate}` : "Varies"}
              </p>
            </article>
          ))
        ) : (
          <p>No professionals found. Try again later.</p>
        )}
      </div>
    </section>
  );
};

export default Professionals;
