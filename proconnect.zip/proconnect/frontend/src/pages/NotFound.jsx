const NotFound = () => {
  return (
    <section className="page-content">
      <h2>Page not found</h2>
      <p>The page you are looking for does not exist.</p>
    </section>
  );
};

export default NotFound;
