import { useEffect, useMemo, useState } from "react";
import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Profile from "./pages/Profile";
import Professionals from "./pages/Professionals";
import Jobs from "./pages/Jobs";
import Applications from "./pages/Applications";
import Support from "./pages/Support";
import NotFound from "./pages/NotFound";
import api from "./api";

function App() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const authValue = useMemo(
    () => ({
      user,
      login: async (credentials) => {
        const response = await api.login(credentials);
        if (response.token) {
          localStorage.setItem("upwork_token", response.token);
          api.setToken(response.token);
          setUser({
            id: response.userId,
            email: response.email,
            username: response.name,
            role: response.role,
          });
        }
        return response;
      },
      register: async (payload) => {
        return api.register(payload);
      },
      logout: () => {
        localStorage.removeItem("upwork_token");
        api.setToken(null);
        setUser(null);
      },
    }),
    [user],
  );

  useEffect(() => {
    const token = localStorage.getItem("upwork_token");
    if (!token) {
      setLoading(false);
      return;
    }

    api.setToken(token);
    api
      .fetchCurrentUser()
      .then((userData) => {
        setUser({ ...userData, username: userData.name || userData.username });
      })
      .catch(() => {
        localStorage.removeItem("upwork_token");
        api.setToken(null);
        setUser(null);
      })
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return <div className="page-shell">Loading application...</div>;
  }

  return (
    <div className="app-shell">
      <BrowserRouter>
        <Navbar user={user} onLogout={authValue.logout} />
        <main className="page-shell">
          <Routes>
            <Route path="/" element={<Home user={user} />} />
            <Route
              path="/login"
              element={
                user ? (
                  <Navigate replace to="/" />
                ) : (
                  <Login onLogin={authValue.login} />
                )
              }
            />
            <Route
              path="/register"
              element={
                user ? (
                  <Navigate replace to="/" />
                ) : (
                  <Register onRegister={authValue.register} />
                )
              }
            />
            <Route path="/jobs" element={<Jobs />} />
            <Route path="/services" element={<Navigate replace to="/jobs" />} />
            <Route path="/professionals" element={<Professionals />} />
            <Route
              path="/applications"
              element={<Applications user={user} />}
            />
            <Route
              path="/bookings"
              element={<Navigate replace to="/applications" />}
            />
            <Route path="/support" element={<Support user={user} />} />
            <Route path="/profile" element={<Profile user={user} />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </main>
      </BrowserRouter>
    </div>
  );
}

export default App;
